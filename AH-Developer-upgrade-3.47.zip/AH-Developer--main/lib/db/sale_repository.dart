import 'dart:async';

import 'package:sqflite/sqflite.dart' show Transaction;

import '../utils/qty_math.dart';
import '../models/held_bill.dart';
import '../models/misc_entities.dart';
import '../models/product.dart';
import '../models/party.dart' show Customer;
import '../models/sale.dart';
import '../services/credit_guard.dart';
import '../services/credit_override_policy.dart';
import '../services/session.dart';
import '../utils/split_payment.dart';
import '../utils/stock_touch_policy.dart';
import '../models/stock_movement.dart' show MovementType;
import 'app_database.dart';
import 'cost_backfill.dart';
import 'customer_repository.dart';
import 'party_repository.dart' show PartyRepository, partyClosing;
import 'product_repository.dart';
import 'recycle_bin_repository.dart';
import '../sync/device_tag.dart';
import '../sync/sync_queue_helper.dart';
import 'stock_ledger.dart';
import '../utils/stock_policy.dart';
import 'watch_util.dart';
import 'unit_cost.dart';

/// One line the user has added to the sale bill before saving — mirrors
/// `SaleLine` (domain) used by SaleActivity.kt's `lines` list. The unit
/// ladder fields are snapshotted so a held bill can be recalled later even if
/// the product's units were edited in between (same as the Kotlin app).
class SaleLine {
  final String itemName;
  final String barcode;
  final double qty;
  final String unit;
  final double unitPrice;
  final double cost;
  final double amount;
  final String mainUnit;
  final String secondaryUnit;
  final double secondaryUnitQty;
  final String tertiaryUnit;
  final double tertiaryUnitQty;

  const SaleLine({
    required this.itemName,
    required this.barcode,
    required this.qty,
    required this.unit,
    required this.unitPrice,
    required this.cost,
    required this.amount,
    this.mainUnit = '',
    this.secondaryUnit = '',
    this.secondaryUnitQty = 0.0,
    this.tertiaryUnit = '',
    this.tertiaryUnitQty = 0.0,
  });

  SaleLine copyWith({double? qty, String? unit, double? unitPrice, double? cost, double? amount}) => SaleLine(
        itemName: itemName,
        barcode: barcode,
        qty: qty ?? this.qty,
        unit: unit ?? this.unit,
        unitPrice: unitPrice ?? this.unitPrice,
        cost: cost ?? this.cost,
        amount: amount ?? this.amount,
        mainUnit: mainUnit,
        secondaryUnit: secondaryUnit,
        secondaryUnitQty: secondaryUnitQty,
        tertiaryUnit: tertiaryUnit,
        tertiaryUnitQty: tertiaryUnitQty,
      );
}

/// Thrown to abort the transaction early (e.g. stock changed under us) —
/// mirrors SaveAbortedException in SaleActivity.kt.
class SaleStockException implements Exception {
  final String message;
  SaleStockException(this.message);
  @override
  String toString() => message;
}

/// Thrown BEFORE anything is written when a credit bill would push a known
/// customer past their credit limit. The screen shows a confirm dialog and,
/// only if the cashier agrees, saves again with `overrideCreditLimit: true`.
/// Mirrors SaveSaleResult / QuickSaleResult.CreditLimitExceeded.
class SaleCreditLimitException implements Exception {
  final String customerName;
  final double creditLimit;
  final double projectedBalance;
  SaleCreditLimitException(this.customerName, this.creditLimit, this.projectedBalance);
  @override
  String toString() =>
      '$customerName ki credit limit ${creditLimit.toStringAsFixed(0)} hai, is bill ke baad balance ${projectedBalance.toStringAsFixed(0)} ho jayega';
}

/// Server-side (cross-device) credit pre-check. No-op unless "Server credit-limit check" is ON and the
/// device is online; any failure => proceed on the local check (fail-open, see CreditGuard).
Future<void> _serverCreditCheck({
  required Customer customer,
  required double amount,
  required String reservationId,
}) async {
  if (amount <= 0.009) return;
  final r = await CreditGuard.instance.reserve(
    customerId: SyncQueueHelper.customerEntityId(customer.toMap()),
    amount: amount,
    reservationId: reservationId,
  );
  if (r.status == CreditCheckStatus.blocked) {
    throw SaleCreditLimitException(customer.name, r.creditLimit ?? customer.creditLimit, r.projected ?? 0.0);
  }
}

/// Mirrors QuickSaleSaveResult.
class QuickSaleSaveResult {
  final String invoice;
  final bool isCredit;
  const QuickSaleSaveResult(this.invoice, this.isCredit);
}

/// Everything the Sale screen needs to re-open a saved bill for editing.
/// Mirrors `SaleForEdit`.
class SaleForEdit {
  final Sale sale;
  final List<SaleItem> items;
  final String customerName;
  final List<SaleLine> lines;

  /// Non-empty only when the bill was saved with 2+ payment rows, so the
  /// screen can re-open the Split Payment dialog pre-filled.
  final List<PayEntry> payments;
  const SaleForEdit(this.sale, this.items, this.customerName, this.lines, [this.payments = const []]);
}

/// Last rate charged to a customer for an item. Mirrors `CustomerItemRate`.
class CustomerItemRate {
  final double unitPrice;
  final String unit;

  /// Us sale ka waqt (ms) jis par ye rate laga tha; 0 = pata nahi.
  final int soldAt;
  const CustomerItemRate(this.unitPrice, this.unit, [this.soldAt = 0]);
}

/// Removes [linkedPaid] (money already recorded by bill-linked payments, each
/// with its own cash row) from the front of the bill's cash-in [rows], so an
/// edited bill never counts it twice. Rows that reach zero are dropped.
/// Mirrors the `linkedToSkip` loop in Kotlin `RoomSaleRepository.saveSale()`.
List<PayEntry> subtractLinkedPaid(List<PayEntry> rows, double linkedPaid) {
  var skip = linkedPaid;
  final out = <PayEntry>[];
  for (final row in rows) {
    var amount = row.amount;
    if (skip > 0.009) {
      final cut = skip < amount ? skip : amount;
      amount -= cut;
      skip -= cut;
    }
    if (amount <= 0.009) continue;
    out.add(PayEntry(row.method, amount));
  }
  return out;
}

class SaleRepository {
  SaleRepository._();
  static final SaleRepository instance = SaleRepository._();

  final _controller = StreamController<List<Sale>>.broadcast();

  /// Har naye subscriber ko PEHLE current list milti hai, phir live updates.
  /// (Pehle sirf pehla subscriber list pata tha — screen dobara khulne par list khali reh jati thi.)
  Stream<List<Sale>> watchAll() => watchWithInitial(_controller, listAll);

  /// Recycle Bin restore ke baad list live refresh.
  Future<void> refreshAfterRestore() => _notify();

  Future<void> _notify() async {
    final rows = await listAll();
    if (!_controller.isClosed) _controller.add(rows);
  }

  Future<List<Sale>> listAll() async {
    final db = await AppDatabase.instance.database;
    final rows = await db.query('sales', orderBy: 'createdAt DESC');
    return rows.map(Sale.fromMap).toList();
  }

  /// Mirrors invoice generation in `saveSale()`: MMyy + last 8 digits of the
  /// current time in milliseconds + `-<deviceTag>`.
  ///
  /// [nowMillis] / [deviceTag] sirf tests ke liye (do devices ka ek hi millisecond simulate karne ke liye).
  String nextInvoiceNumber(int saleDateMillis, {int? nowMillis, String? deviceTag}) {
    final date = DateTime.fromMillisecondsSinceEpoch(saleDateMillis);
    final mmYY = '${date.month.toString().padLeft(2, '0')}${(date.year % 100).toString().padLeft(2, '0')}';
    final suffix = (nowMillis ?? DateTime.now().millisecondsSinceEpoch).toString();
    // Device tag (purchase `nextBillNo()` jaisa): invoice hi primary key aur cloud doc id hai, aur akele
    // 8-digit ms suffix har ~27.7 ghante baad dohrate hain — do devices ka bill sync par ek dusre ko
    // overwrite kar sakta tha.
    return '${mmYY + suffix.substring(suffix.length - 8)}-${deviceTag ?? DeviceTag.current}';
  }

  // ------------------------------------------------------------ Admin guard

  /// Edit / delete / return of a SAVED bill is admin-only. Checked here too
  /// (not just by hiding buttons) so no other screen can bypass it.
  void _requireAdmin() {
    if (!Session.isAdmin) {
      throw ArgumentError('Saved sale mein tabdeeli sirf Admin kar sakta hai');
    }
  }

  Future<void> _logAudit(String action, String reference, String details) async {
    try {
      final db = await AppDatabase.instance.database;
      await db.insert('audit', {
        'username': Session.username ?? 'unknown',
        'action': action,
        'reference': reference,
        'details': details,
        'createdAt': DateTime.now().millisecondsSinceEpoch,
      });
    } catch (_) {
      // Audit must never break a save that already committed.
    }
  }

  /// Stock wapas + ledger row (SALE_REVERSAL / SALE_EDIT_REVERSAL), ek hi transaction mein.
  Future<void> _increaseStock(Transaction txn, String barcode, double smallest, int now,
      {required String type, required String reference}) async {
    await txn.rawUpdate(
      'UPDATE products SET stock = stock + ?, dirty = 1, updatedAt = ? WHERE barcode = ?',
      [smallest, now, barcode],
    );
    await SyncQueueHelper.enqueueStockDelta(txn, barcode, smallest);
    await StockLedger.log(txn, barcode: barcode, type: type, signedQty: smallest, reference: reference, now: now);
  }

  Future<void> _adjustCustomerBalance(Transaction txn, int customerId, double delta, int now) async {
    await txn.rawUpdate(
      'UPDATE customers SET balance = balance + ?, dirty = 1, updatedAt = ? WHERE id = ?',
      [delta, now, customerId],
    );
    await SyncQueueHelper.enqueueBalanceDelta(txn, customer: true, partyId: customerId, delta: delta);
  }

  /// Deletes the cash-drawer rows of [invoice] AND queues each removal so
  /// other devices drop them too (Kotlin deleteCashTransactionsByReference).
  Future<void> _deleteCashByReference(Transaction txn, String invoice) =>
      SyncQueueHelper.deleteCashTransactionsByReference(txn, invoice);

  /// Kotlin `PaymentDao.linkedPaidForBill()`: standalone payments recorded via
  /// "Receive Payment > link to bill" (billReference == bill, but NOT the bill's
  /// own embedded row, whose reference == bill). They are already inside the
  /// bill's `paid`, so an edit must not record that money again in the cash book.
  Future<double> _linkedPaidForBill(Transaction txn, String bill) async {
    final r = await txn.rawQuery(
      'SELECT COALESCE(SUM(amount),0) AS s FROM payments WHERE billReference = ? AND reference != ?',
      [bill, bill],
    );
    if (r.isEmpty) return 0.0;
    return (r.first['s'] as num?)?.toDouble() ?? 0.0;
  }

  /// Kotlin `reverseCashByReference()`: the original cash rows stay untouched;
  /// a new dated reversal row (`return:<ref>`) is written instead, split across
  /// the original methods in proportion.
  Future<void> _reverseCash(Transaction txn, String reference, double amount, String type,
      String label, int now) async {
    if (amount <= 0.009) return;
    final rows = await txn.query('cash_transactions', where: 'reference=?', whereArgs: [reference]);
    if (rows.isEmpty) return;
    final originalTotal = rows.fold<double>(0, (sum, r) => sum + (r['amount'] as num).toDouble());
    if (originalTotal <= 0.009) return;
    final ratio = (amount / originalTotal).clamp(0.0, 1.0);
    for (final r in rows) {
      final portion = (r['amount'] as num).toDouble() * ratio;
      if (portion <= 0.009) continue;
      final reversal = CashTransaction(
        type: type,
        method: (r['method'] as String?) ?? 'cash',
        amount: portion,
        reason: label,
        reference: 'return:$reference',
        createdAt: now,
      );
      final id = await txn.insert('cash_transactions', reversal.toMap());
      await _enqueueSync(txn, 'cash_transaction', id.toString(), 'create', reversal.toMap());
    }
  }

  /// Kotlin `SyncQueueHelper.voidLinkedPayments()`: bill-linked payments would
  /// otherwise live on as orphan "standalone" payments after a return/delete.
  ///  - [refundType] != null (RETURN): money goes back -> dated reversal of each
  ///    linked payment's cash row, then the payment row is dropped.
  ///  - [refundType] == null (DELETE): payment row + its cash rows are dropped.
  /// Party balance is NOT touched: the bill's own reversal uses total - paid and
  /// `paid` already includes these payments.
  Future<void> _voidLinkedPayments(Transaction txn, String billRef, int now,
      {String? refundType, String refundLabel = ''}) async {
    final rows = await txn.query('payments',
        where: 'billReference = ? AND reference != ?', whereArgs: [billRef, billRef]);
    for (final p in rows) {
      final ref = (p['reference'] as String?) ?? '';
      if (refundType != null) {
        await _reverseCash(txn, ref, (p['amount'] as num).toDouble(), refundType, refundLabel, now);
      } else {
        await _deleteCashByReference(txn, ref);
      }
      await SyncQueueHelper.deletePaymentRow(txn, Map<String, Object?>.from(p));
    }
  }

  // ---------------------------------------------------------------- Load edit

  /// Re-opens a saved bill. Mirrors `LoadSaleForEditUseCase`.
  Future<SaleForEdit?> loadForEdit(String invoice) async {
    _requireAdmin();
    final db = await AppDatabase.instance.database;
    final saleRows = await db.query('sales', where: 'invoice=?', whereArgs: [invoice], limit: 1);
    if (saleRows.isEmpty) return null;
    final sale = Sale.fromMap(saleRows.first);
    final itemRows = await db.query('sale_items', where: 'invoice=?', whereArgs: [invoice], orderBy: 'id ASC');
    final items = itemRows.map(SaleItem.fromMap).toList();

    var customerName = '';
    if (sale.customerId != null) {
      final c = await db.query('customers', where: 'id=?', whereArgs: [sale.customerId], limit: 1);
      if (c.isNotEmpty) customerName = (c.first['name'] as String?) ?? '';
    }

    final lines = <SaleLine>[];
    for (final si in items) {
      final pr = await db.query('products', where: 'barcode=?', whereArgs: [si.barcode], limit: 1);
      final product = pr.isEmpty ? null : Product.fromMap(pr.first);
      lines.add(SaleLine(
        itemName: si.product,
        barcode: si.barcode,
        qty: si.qty,
        unit: si.unit.isEmpty ? (product?.unit ?? '') : si.unit,
        unitPrice: si.unitPrice,
        cost: si.cost,
        amount: si.amount,
        mainUnit: product?.unit ?? '',
        secondaryUnit: product?.secondaryUnit ?? '',
        secondaryUnitQty: product?.secondaryUnitQty ?? 0.0,
        tertiaryUnit: product?.tertiaryUnit ?? '',
        tertiaryUnitQty: product?.tertiaryUnitQty ?? 0.0,
      ));
    }
    // Mirrors paymentsForInvoice(): the bill's own cash-in rows, oldest first.
    // Only 2+ rows count as a split (a single row is the normal method+paid).
    final cashRows = await db.query('cash_transactions',
        where: 'reference=? AND type=? AND reason=?', whereArgs: [invoice, 'IN', 'Sale'], orderBy: 'id ASC');
    final payments = cashRows
        .map((r) => PayEntry(_methodTitle((r['method'] as String?) ?? 'cash'), (r['amount'] as num).toDouble()))
        .toList();
    return SaleForEdit(sale, items, customerName, lines, payments.length >= 2 ? payments : const <PayEntry>[]);
  }

  static String _methodTitle(String m) => m.toLowerCase() == 'bank' ? 'Bank' : 'Cash';

  /// Double-bill alert: an existing, non-returned bill for the same customer
  /// (blank = Walk-in), same total, on the same calendar day as [saleDateMillis].
  /// [excludeInvoice] skips the bill being edited. Returns null when none.
  Future<Sale?> findDuplicateSale({
    required String customerName,
    required double total,
    required int saleDateMillis,
    String? excludeInvoice,
  }) async {
    final db = await AppDatabase.instance.database;
    final rows = await db.rawQuery(
      'SELECT s.*, c.name AS _cname FROM sales s LEFT JOIN customers c ON c.id = s.customerId '
      "WHERE s.status != 'returned' ORDER BY s.createdAt DESC",
    );
    final wantedDate = DateTime.fromMillisecondsSinceEpoch(saleDateMillis);
    for (final r in rows) {
      final sale = Sale.fromMap(r);
      if (excludeInvoice != null && sale.invoice == excludeInvoice) continue;
      if (isDuplicateSale(
        candidateCustomer: (r['_cname'] as String?) ?? '',
        candidateTotal: sale.total,
        candidateDate: DateTime.fromMillisecondsSinceEpoch(sale.createdAt),
        wantedCustomer: customerName,
        wantedTotal: total,
        wantedDate: wantedDate,
      )) {
        return sale;
      }
    }
    return null;
  }

  /// Mirrors `saveSale()` (RoomSaleRepository) for BOTH a new bill and — when
  /// [editInvoice] is given — an edit of a saved one (admin only).
  ///
  /// New bill: checks stock for every line against current product state,
  /// creates the customer if new, inserts the sale + items, decreases stock,
  /// adds any due to the customer's balance and records a cash-in.
  ///
  /// Edit: inside the SAME transaction it first gives back stock only for the
  /// original rows that were actually changed/removed ([saleEditDiff]),
  /// reverses the original due, replaces the items and cash rows, updates the
  /// sale row IN PLACE (status is kept), then re-applies stock only for
  /// changed lines. A line left untouched never touches stock, so an edit of
  /// e.g. just the customer can't fail with a false "stock badal gaya".
  ///
  /// Throws [SaleStockException] if a line's stock is no longer available,
  /// [SaleCreditLimitException] (unless [overrideCreditLimit]) or
  /// [ArgumentError] for bad input / a non-admin edit.
  Future<String> saveSale({
    required List<SaleLine> lines,
    required String customerName,
    required double discountInput,
    required double paidInput,
    required String saleType, // 'retail' or 'wholesale'
    required int saleDateMillis,
    String paymentMethod = 'Cash',
    List<PayEntry> payments = const [],
    bool overrideCreditLimit = false,
    String? editInvoice,
    // Kotlin SaleSaveResult.stockWarnings: agar kisi line ka stock update na ho saka
    // (product nahi mila / 0 rows) to yahan warning aati hai; caller dikhata hai.
    List<String>? stockWarnings,
    // Udhaar bill ki payment date (din ki shuruaat, millis). null = pehle wali (edit) ya 0 (naya) rakho.
    int? dueDateMillis,
  }) async {
    final isEdit = editInvoice != null;
    if (isEdit) _requireAdmin();

    if (lines.isEmpty) {
      throw ArgumentError('Add at least one item');
    }
    if (!discountInput.isFinite || discountInput < 0) {
      throw ArgumentError('Discount finite aur zero ya us se zyada hona chahiye');
    }
    if (!paidInput.isFinite || paidInput < 0) {
      throw ArgumentError('Paid amount finite aur zero ya us se zyada hona chahiye');
    }
    for (final line in lines) {
      if (!line.qty.isFinite || line.qty <= 0.0) {
        throw ArgumentError('"${line.itemName}" ki qty finite aur 0 se zyada honi chahiye');
      }
      if (!line.unitPrice.isFinite || line.unitPrice < 0.0) {
        throw ArgumentError('"${line.itemName}" ka rate finite aur negative nahi ho sakta');
      }
      if (!line.amount.isFinite || line.amount < 0.0 || !line.cost.isFinite || line.cost < 0.0) {
        throw ArgumentError('"${line.itemName}" ka amount/cost valid hona chahiye');
      }
    }

    final subtotal = lines.fold<double>(0, (sum, l) => sum + l.amount);
    if (!subtotal.isFinite) throw ArgumentError('Sale total finite hona chahiye');
    // Mirrors DiscountCalculator.compute() inline (kept in sync with
    // lib/utils/discount_calculator.dart).
    final safeSubtotal = subtotal < 0 ? 0.0 : subtotal;
    final discount = discountInput.clamp(0.0, safeSubtotal);
    // Bill total poore rupee par (nearest Rs), same as DiscountCalculator.
    final rawTotal = safeSubtotal - discount;
    final total = rawTotal < 0 ? 0.0 : rawTotal.roundToDouble();
    // Split Payment: when rows exist their sum IS the paid amount.
    final cleanRows = cleanPayments(payments);
    final paid = effectivePaidInput(cleanRows, paidInput).clamp(0.0, total);
    final due = (total - paid) < 0 ? 0.0 : (total - paid);

    if (due > 0.009 && customerName.trim().isEmpty) {
      throw ArgumentError('Due amount ke liye Customer zaroori hai');
    }

    final db = await AppDatabase.instance.database;

    // `final` so they stay promotable (non-null) inside the transaction closure.
    final Sale? original;
    final List<SaleItem> originalItems;
    if (isEdit) {
      final rows = await db.query('sales', where: 'invoice=?', whereArgs: [editInvoice], limit: 1);
      if (rows.isEmpty) {
        throw ArgumentError('Ye bill nahi mila — shayad delete ho chuka hai');
      }
      original = Sale.fromMap(rows.first);
      if (original.status == 'returned') {
        throw ArgumentError('Returned sale edit nahi ho sakti (stock aur balance do baar ulta ho jate hain)');
      }
      final itemRows =
          await db.query('sale_items', where: 'invoice=?', whereArgs: [editInvoice], orderBy: 'id ASC');
      originalItems = itemRows.map(SaleItem.fromMap).toList();
    } else {
      original = null;
      originalItems = const <SaleItem>[];
    }

    final method = paymentMethodLabel(paid: paid, payments: cleanRows, singleMethod: paymentMethod);
    final customers = await CustomerRepository.instance.listAll();
    final customer =
        customers.where((c) => c.name.toLowerCase() == customerName.trim().toLowerCase()).firstOrNull;

    // A bill-linked payment belongs to the original party ledger. Reassigning
    // the bill alone would leave that payment attached to the old customer while
    // its amount is carried into the new customer's paid total. Refuse the edit
    // until the payment is explicitly unlinked/reassigned in the payment flow.
    if (original != null && original.customerId != customer?.id) {
      final linked = await db.rawQuery(
        'SELECT COALESCE(SUM(amount), 0) AS total FROM payments WHERE billReference = ? AND reference != ?',
        [original.invoice, original.invoice],
      );
      final linkedAmount = (linked.first['total'] as num?)?.toDouble() ?? 0.0;
      if (linkedAmount > 0.009) {
        throw ArgumentError('Linked payment maujood hai. Pehle payment ko unlink/reassign karen, phir customer badlein.');
      }
    }

    // Bill-linked payments (Receive Payment > link to bill) already hold real money with their own cash rows.
    // Total unse neeche ho jaye to `paid` clamp hota hai aur extra raqam na cash book mein rehti hai, na party
    // balance (advance) mein — chupke se gayab. Is liye aisa edit rok do; pehle payment edit/delete ho.
    if (original != null) {
      final linkedRows = await db.rawQuery(
        'SELECT COALESCE(SUM(amount), 0) AS total FROM payments WHERE billReference = ? AND reference != ?',
        [original.invoice, original.invoice],
      );
      final linkedPaid = (linkedRows.first['total'] as num?)?.toDouble() ?? 0.0;
      if (total + 0.009 < linkedPaid) {
        throw ArgumentError(
            'Is bill par Rs ${linkedPaid.toStringAsFixed(0)} ki linked payment maujood hai, bill total (Rs ${total.toStringAsFixed(0)}) us se kam nahi ho sakta. Pehle payment ko edit ya delete karen.');
      }
    }

    // Credit-limit validation is performed against the transaction snapshot below.

    final invoice = editInvoice ?? nextInvoiceNumber(saleDateMillis);
    final now = DateTime.now().millisecondsSinceEpoch;

    if (overrideCreditLimit && !await CreditOverridePolicy.currentUserMayOverride()) {
      throw ArgumentError('Credit limit se upar ka bill save karne ke liye admin ya manager ki ijazat zaroori hai.');
    }

    // Cross-device check (opt-in, fail-open). Runs before anything is written; the local transaction check
    // below still runs afterwards.
    if (customer != null && customer.creditLimit > 0.0 && !overrideCreditLimit) {
      var net = due;
      if (original != null && original.customerId == customer.id) net -= (original.total - original.paid);
      await _serverCreditCheck(
          customer: customer, amount: net, reservationId: 'sale:$invoice:${DeviceTag.current}');
    }

    await db.transaction((txn) async {
      // Same-device concurrent saves are serialized and validated against the
      // ledger snapshot used by this write. Cross-device enforcement still
      // requires a server-authoritative transaction when cloud writes are enabled.
      if (customer?.id != null && !overrideCreditLimit) {
        final freshRows = await txn.query('customers', where: 'id = ?', whereArgs: [customer!.id], limit: 1);
        if (freshRows.isNotEmpty) {
          final freshCustomer = Customer.fromMap(freshRows.first);
          if (freshCustomer.creditLimit > 0.0) {
            final liveRunning = await PartyRepository.instance.liveCustomerBalanceIn(txn, freshCustomer.id!);
            var projected = partyClosing(opening: freshCustomer.openingBalance, running: liveRunning,
                stuck: freshCustomer.stuckBalance) + due;
            if (original != null && original.customerId == freshCustomer.id) {
              projected -= (original.total - original.paid);
            }
            if (projected > freshCustomer.creditLimit + 0.009) {
              throw SaleCreditLimitException(freshCustomer.name, freshCustomer.creditLimit, projected);
            }
          }
        }
      }

      final diff = original != null ? saleEditDiff(lines, originalItems) : null;
      bool needsStock(int index) => diff == null || diff.changedLineIndices.contains(index);

      if (original != null) {
        // Only original rows that were changed/removed give stock back —
        // untouched rows keep the stock they already deducted.
        for (final si in diff!.itemsToReverse) {
          final pr = await txn.query('products', where: 'barcode=?', whereArgs: [si.barcode], limit: 1);
          final product = pr.isEmpty ? null : Product.fromMap(pr.first);
          await _increaseStock(txn, si.barcode, saleItemSmallestQty(si, product), now,
              type: MovementType.saleEditReversal, reference: invoice);
        }
        // Reverse the original due (or advance) — nonzero either way.
        final originalOutstanding = original.total - original.paid;
        if (original.customerId != null && originalOutstanding.abs() > 0.009) {
          await _adjustCustomerBalance(txn, original.customerId!, -originalOutstanding, now);
        }
        await txn.delete('sale_items', where: 'invoice=?', whereArgs: [invoice]);
        await _deleteCashByReference(txn, invoice);
      }

      // Stock availability check per product (after any reversal above) —
      // aborts the whole save if short. Only lines that will deduct stock
      // are checked, so an untouched line whose product was since deleted
      // can't block an unrelated edit.
      final indicesByBarcode = <String, List<int>>{};
      for (var i = 0; i < lines.length; i++) {
        indicesByBarcode.putIfAbsent(lines[i].barcode, () => <int>[]).add(i);
      }
      final productByBarcode = <String, Product>{};
      final allowShort = await StockPolicy.readFrom(txn);
      for (final entry in indicesByBarcode.entries) {
        final anyNeedsStock = entry.value.any(needsStock);
        final rows = await txn.query('products', where: 'barcode=?', whereArgs: [entry.key], limit: 1);
        if (rows.isEmpty) {
          if (anyNeedsStock) {
            throw SaleStockException('Stock badal gaya hai — item nahi mila. Bill dobara check karen.');
          }
          continue;
        }
        final product = Product.fromMap(rows.first);
        if (anyNeedsStock) {
          final needed = entry.value
              .where(needsStock)
              .fold<double>(0, (sum, i) => sum + product.toSmallestUnits(lines[i].qty, lines[i].unit));
          if (!hasEnoughStock(product.stock, needed)) {
            if (!allowShort) {
              throw SaleStockException(
                'Stock badal gaya hai — "${product.name}" mein sirf ${_trimNum(product.stock)} ${product.smallestUnitName()} available hai. Bill dobara check karen.',
              );
            }
            // Setting ON: sale rukti nahi — stock minus mein jata hai, sirf warning.
            stockWarnings?.add(StockPolicy.shortWarning(product.name, product.stock, needed, product.smallestUnitName()));
          }
        }
        productByBarcode[entry.key] = product;
      }

      int? customerId = customer?.id;
      if (customerId == null && customerName.trim().isNotEmpty) {
        customerId = await txn.insert('customers', {
          'name': customerName.trim(),
          'phone': '',
          'creditLimit': 0.0,
          'openingBalance': 0.0,
          'balance': 0.0,
          'updatedAt': now,
          'dirty': 1,
        });
        // FIX: naya customer cloud par bhi jaye (pehle sirf due wale bill ka increment_balance jata tha;
        // poora paid bill hone par ye customer doosre devices par kabhi nahi pahunchta tha).
        await SyncQueueHelper.enqueueCustomer(txn, customerId);
      }

      // A brand-new bill must not reuse an invoice number (double-tap /
      // retry); an edit reuses its own row, so it is exempt.
      if (original == null) {
        final dup = await txn.query('sales', where: 'invoice=?', whereArgs: [invoice], limit: 1);
        if (dup.isNotEmpty) {
          throw SaleStockException('Invoice number "$invoice" pehle se mojood hai. Dobara try karen.');
        }
      }

      final sale = Sale(
        invoice: invoice,
        customerId: customerId,
        subtotal: subtotal,
        discount: discount,
        tax: 0.0,
        total: total,
        paid: paid,
        paymentMethod: method.toLowerCase(),
        saleType: saleType,
        createdAt: saleDateMillis,
        // A returned sale stays returned through an edit.
        status: original?.status ?? 'active',
        updatedAt: now,
        // Edit par dueDate reset na ho (Kotlin: "reset-to-0 dueDate on every edit" FIX).
        dueDate: dueDateMillis ?? original?.dueDate ?? 0,
      );
      if (original != null) {
        // True in-place UPDATE keyed by invoice (never delete + re-insert).
        await txn.update('sales', sale.toMap(), where: 'invoice=?', whereArgs: [invoice]);
      } else {
        await txn.insert('sales', sale.toMap());
      }

      // costPending: har barcode ka stock deduct hone se PEHLE (edit mein reversal ke baad), line ba line ghatta hua.
      final runningStock = <String, double>{
        for (final e in productByBarcode.entries) e.key: e.value.stock,
      };
      for (var i = 0; i < lines.length; i++) {
        final line = lines[i];
        // An untouched line keeps the factor frozen when it was first sold;
        // re-stamping it with today's ladder would make a later
        // delete/return reverse a different qty than was deducted.
        final unchangedOriginal = diff?.unchangedOriginalByIndex[i];
        final factor = unchangedOriginal != null
            ? unchangedOriginal.conversionFactor
            : (productByBarcode[line.barcode]?.smallestPerUnitOf(line.unit) ?? 0.0);
        var lineCost = line.cost;
        var pendingQty = 0.0;
        var pendingEst = 0.0;
        var backfillLog = '';
        if (unchangedOriginal != null) {
          // Bilkul na badli line: pending status aur bhari hui cost jaisi thi waisi (stock dobara touch nahi hota).
          pendingQty = unchangedOriginal.pendingQty;
          pendingEst = unchangedOriginal.pendingEst;
          backfillLog = unchangedOriginal.backfillLog;
          if (pendingQty > kPendingEpsilon || backfillLog.isNotEmpty) lineCost = unchangedOriginal.cost;
        } else {
          final prod = productByBarcode[line.barcode];
          if (prod != null) {
            final needed = prod.toSmallestUnits(line.qty, line.unit);
            final before = runningStock[line.barcode] ?? prod.stock;
            final fac = prod.smallestUnitFactor();
            final p = CostBackfill.pendingForSale(
              needed: needed,
              stockBefore: before,
              costPerSmallest: costPerSmallestOf(prod.cost, fac),
              lineCost: line.cost,
            );
            pendingQty = p.pendingQty;
            pendingEst = p.pendingEst;
            runningStock[line.barcode] = before - needed;
          }
        }
        await txn.insert('sale_items', {
          'invoice': invoice,
          'barcode': line.barcode,
          'product': line.itemName,
          'qty': line.qty,
          'unit': line.unit,
          'unitPrice': line.unitPrice,
          'cost': lineCost,
          'amount': line.amount,
          'conversionFactor': factor,
          'pendingQty': pendingQty,
          'pendingEst': pendingEst,
          'backfillLog': backfillLog,
        });
      }

      await _enqueueSync(txn, 'sale', invoice, original != null ? 'update' : 'create', {
        'invoice': invoice,
        'customerId': customerId,
        'total': total,
        'paid': paid,
        'itemCount': lines.length,
      });

      for (var i = 0; i < lines.length; i++) {
        if (!needsStock(i)) continue;
        final line = lines[i];
        final product = productByBarcode[line.barcode];
        if (product == null) continue;
        final smallest = product.toSmallestUnits(line.qty, line.unit);
        final rowsAffected = await txn.rawUpdate(
          'UPDATE products SET stock = stock - ?, dirty = 1, updatedAt = ? WHERE barcode = ?',
          [smallest, now, line.barcode],
        );
        if (rowsAffected != 1) {
          // Warning nahi: poori sale rollback, warna bill ban jata hai aur stock kam nahi hota.
          throw SaleStockException('"${line.itemName}" ka stock update nahi ho saka. Sale save nahi hui — dobara try karen.');
        }
        await SyncQueueHelper.enqueueStockDelta(txn, line.barcode, -smallest);
        await StockLedger.log(txn,
            barcode: line.barcode,
            type: original != null ? MovementType.saleEdit : MovementType.sale,
            signedQty: -smallest,
            reference: invoice,
            now: now);
      }

      if (customerId != null && (total - paid).abs() > 0.009) {
        await _adjustCustomerBalance(txn, customerId, total - paid, now);
      }

      // One cash-in row per payment method (Split Payment); the single-method
      // path is exactly the old one-row behaviour. Dated with the SALE's date
      // (not today) so a back-dated bill shows in the Cash Register on its own
      // day.
      final effectiveRows = cleanRows.isNotEmpty
          ? cleanRows
          : (paid > 0.009 ? [PayEntry(paymentMethod, paid)] : const <PayEntry>[]);
      if (paid > 0.009) {
        // Editing a bill that already had bill-linked payments: `paid` (pre-filled
        // from sale.paid) already includes them and they keep their own cash row,
        // so re-creating a full-`paid` cash-in would count that money twice.
        final linkedPaid = original != null ? await _linkedPaidForBill(txn, invoice) : 0.0;
        // Rows can add up to more than the bill (paid was clamped to total):
        // trim the overshoot off the last rows so cash-in == paid exactly.
        var remaining = paid;
        final trimmed = <PayEntry>[];
        for (final row in effectiveRows) {
          if (remaining <= 0.009) break;
          final amount = row.amount > remaining ? remaining : row.amount;
          remaining -= amount;
          trimmed.add(PayEntry(row.method, amount));
        }
        final cashRows = subtractLinkedPaid(trimmed, linkedPaid);
        for (final row in cashRows) {
          final amount = row.amount;
          final cashTx = CashTransaction(
            type: 'IN',
            method: row.method.toLowerCase(),
            amount: amount,
            reason: 'Sale',
            reference: invoice,
            createdAt: saleDateMillis,
          );
          final cashTxId = await txn.insert('cash_transactions', cashTx.toMap());
          await _enqueueSync(txn, 'cash_transaction', cashTxId.toString(), 'create', cashTx.toMap());
        }
      }
    });

    await ProductRepository.instance.refresh();
    await CustomerRepository.instance.refresh();
    await _notify();
    await _logAudit(
      isEdit ? 'sale_edit' : 'sale_create',
      invoice,
      'total=$total paid=$paid method=$method customer=${customerName.trim().isEmpty ? 'walk-in' : customerName.trim()}',
    );
    return invoice;
  }

  // ------------------------------------------------------------ Delete / Return

  /// Deletes a saved sale (admin only): gives its stock back, reverses its
  /// due/advance on the customer, and removes the bill, its items and its cash
  /// rows — one transaction. Mirrors `deleteSale()`.
  Future<void> deleteSale(String invoice) async {
    _requireAdmin();
    final db = await AppDatabase.instance.database;
    Sale? deleted;
    await db.transaction((txn) async {
      final rows = await txn.query('sales', where: 'invoice=?', whereArgs: [invoice], limit: 1);
      if (rows.isEmpty) throw ArgumentError('Ye bill nahi mila');
      final sale = Sale.fromMap(rows.first);
      final itemRows = await txn.query('sale_items', where: 'invoice=?', whereArgs: [invoice]);
      final now = DateTime.now().millisecondsSinceEpoch;
      // Returned sale ka stock aur customer ka due returnSale() mein pehle hi ulta ho chuka hai —
      // delete par dobara karne se stock do baar barh jata aur customer ka balance do baar ghat jata tha.
      final alreadyReturned = sale.status == 'returned';

      if (!alreadyReturned) {
        for (final r in itemRows) {
          final si = SaleItem.fromMap(r);
          final pr = await txn.query('products', where: 'barcode=?', whereArgs: [si.barcode], limit: 1);
          final product = pr.isEmpty ? null : Product.fromMap(pr.first);
          await _increaseStock(txn, si.barcode, saleItemSmallestQty(si, product), now,
              type: MovementType.saleReversal, reference: invoice);
        }
        final outstanding = sale.total - sale.paid;
        if (sale.customerId != null && outstanding.abs() > 0.009) {
          await _adjustCustomerBalance(txn, sale.customerId!, -outstanding, now);
        }
      }
      // Recycle Bin: delete se pehle poora snapshot (bill + items + cash rows + bill-linked payments).
      final linkedPays = await txn.query('payments',
          where: 'billReference = ? AND reference != ?', whereArgs: [invoice, invoice]);
      final cashRefs = <String>{
        invoice,
        if (alreadyReturned) 'return:$invoice',
        for (final p in linkedPays) (p['reference'] as String?) ?? '',
      }..remove('');
      final cashRows = await txn.query('cash_transactions',
          where: 'reference IN (${List.filled(cashRefs.length, '?').join(',')})', whereArgs: cashRefs.toList());
      String who = 'Walk-in';
      if (sale.customerId != null) {
        final cr = await txn.query('customers', columns: ['name'], where: 'id = ?', whereArgs: [sale.customerId], limit: 1);
        if (cr.isNotEmpty) who = (cr.first['name'] as String?) ?? who;
      }
      await RecycleBinRepository.record(
        txn,
        kind: RecycleBinRepository.kindSale,
        refKey: invoice,
        title: 'Sale $invoice',
        subtitle: who,
        amount: sale.total,
        rows: {
          'sales': [Map<String, Object?>.from(rows.first)],
          'sale_items': [for (final r in itemRows) Map<String, Object?>.from(r)],
          'payments': [for (final r in linkedPays) Map<String, Object?>.from(r)],
          'cash_transactions': [for (final r in cashRows) Map<String, Object?>.from(r)],
          'meta': [
            {'alreadyReturned': alreadyReturned ? 1 : 0}
          ],
        },
      );

      await txn.delete('sale_items', where: 'invoice=?', whereArgs: [invoice]);
      await txn.delete('sales', where: 'invoice=?', whereArgs: [invoice]);
      await _deleteCashByReference(txn, invoice);
      // Return ki dated reversal rows bhi: asli rows hat gayin, akeli reversal cash book ko minus kar deti.
      if (alreadyReturned) await _deleteCashByReference(txn, 'return:$invoice');
      // Bill-linked payments must not survive as orphan standalone payments.
      await _voidLinkedPayments(txn, invoice, now);
      await _enqueueSync(txn, 'sale', invoice, 'delete', {'invoice': invoice});
      deleted = sale;
    });

    await ProductRepository.instance.refresh();
    await CustomerRepository.instance.refresh();
    await _notify();
    final s = deleted;
    if (s != null) {
      await _logAudit('sale_delete', invoice,
          'total=${s.total} paid=${s.paid} customerId=${s.customerId ?? 'walk-in'}');
    }
  }

  /// Returns a saved sale (admin only): stock back, one `returns` row per
  /// line (so it shows in Sale Returns reports), customer due reversed, a
  /// dated cash-OUT reversal, and status -> 'returned'. The original sale's
  /// cash history is kept. Mirrors `returnSale()` (HistoryActivity).
  Future<void> returnSale(String invoice) async {
    _requireAdmin();
    final db = await AppDatabase.instance.database;
    Sale? returned;
    await db.transaction((txn) async {
      final rows = await txn.query('sales', where: 'invoice=?', whereArgs: [invoice], limit: 1);
      if (rows.isEmpty) throw ArgumentError('Ye bill nahi mila');
      final sale = Sale.fromMap(rows.first);
      if (sale.status == 'returned') throw ArgumentError('Ye sale pehle hi return ho chuki hai');
      final itemRows = await txn.query('sale_items', where: 'invoice=?', whereArgs: [invoice]);
      final now = DateTime.now().millisecondsSinceEpoch;

      // Line amounts discount / rounding se PEHLE ke hain; refund bill total ke mutabiq ho, is liye har line
      // total/subtotal se scale hoti hai aur aakhri line baqi farq (rounding) utha leti hai.
      final lineSum = itemRows.fold<double>(0, (sum, r) => sum + ((r['amount'] as num?)?.toDouble() ?? 0.0));
      final scale = lineSum > 0.009 ? sale.total / lineSum : 1.0;
      var returnedSoFar = 0.0;
      var lineNo = 0;
      for (final r in itemRows) {
        lineNo++;
        final si = SaleItem.fromMap(r);
        final pr = await txn.query('products', where: 'barcode=?', whereArgs: [si.barcode], limit: 1);
        final product = pr.isEmpty ? null : Product.fromMap(pr.first);
        await _increaseStock(txn, si.barcode, saleItemSmallestQty(si, product), now,
            type: MovementType.saleReversal, reference: invoice);
        final isLast = lineNo == itemRows.length;
        final retAmount = lineSum > 0.009
            ? (isLast ? sale.total - returnedSoFar : si.amount * scale)
            : si.amount;
        returnedSoFar += retAmount;
        final ret = ReturnLine(
          reference: invoice,
          type: 'sale',
          barcode: si.barcode,
          qty: si.qty,
          amount: retAmount,
          createdAt: now,
        );
        final retId = await txn.insert('returns', ret.toMap());
        await _enqueueSync(txn, 'return', retId.toString(), 'create', ret.toMap());
      }

      final outstanding = sale.total - sale.paid;
      if (sale.customerId != null && outstanding.abs() > 0.009) {
        await _adjustCustomerBalance(txn, sale.customerId!, -outstanding, now);
      }

      // Dated reversal instead of deleting the original cash rows: keeps the
      // sale day's history and leaves a visible trace of the return today.
      await _reverseCash(txn, invoice, sale.paid, 'OUT', 'Sale Return', now);
      // Bill-linked payments: refund (dated reversal) and drop the payment rows.
      await _voidLinkedPayments(txn, invoice, now, refundType: 'OUT', refundLabel: 'Sale Return');

      await txn.update(
        'sales',
        {'status': 'returned', 'updatedAt': now, 'dirty': 1},
        where: 'invoice=?',
        whereArgs: [invoice],
      );
      await _enqueueSync(txn, 'sale', invoice, 'update', {
        'invoice': invoice,
        'customerId': sale.customerId,
        'total': sale.total,
        'paid': sale.paid,
        'status': 'returned',
      });
      returned = sale;
    });

    await ProductRepository.instance.refresh();
    await CustomerRepository.instance.refresh();
    await _notify();
    final s = returned;
    if (s != null) {
      await _logAudit('sale_return', invoice, 'total=${s.total} paid=${s.paid}');
    }
  }

  /// Partial sale return (admin). [requested] = sale_items.id -> return qty. Mirrors the purchase side
  /// (`PurchaseHistoryRepository.returnItems`): sirf wahi qty stock mein wapas aati hai, har wapas line ka
  /// `returns` row banta hai, bill ka total/paid kam hota hai, customer ka balance sirf farq se badalta hai
  /// aur jo paisa ab bill se zyada reh gaya wo dated cash-OUT reversal se wapas hota hai. Sab lines ki poori
  /// qty ho to purani poori-bill [returnSale] chalti hai (status 'returned').
  Future<void> returnSaleItems(String invoice, Map<int, double> requested) async {
    _requireAdmin();
    final db = await AppDatabase.instance.database;

    // Poori bill? (har line ki poori qty) => purana returnSale (exact total + status 'returned').
    final pre = await db.query('sale_items', where: 'invoice=?', whereArgs: [invoice]);
    if (pre.isNotEmpty) {
      var all = true;
      for (final r in pre) {
        final id = r['id'] as int?;
        final qty = (r['qty'] as num?)?.toDouble() ?? 0.0;
        final want = id == null ? null : requested[id];
        if (want == null || !want.isFinite || want < qty - 0.0001) {
          all = false;
          break;
        }
      }
      if (all) return returnSale(invoice);
    }

    double returnedTotal = 0;
    await db.transaction((txn) async {
      final rows = await txn.query('sales', where: 'invoice=?', whereArgs: [invoice], limit: 1);
      if (rows.isEmpty) throw ArgumentError('Ye bill nahi mila');
      final sale = Sale.fromMap(rows.first);
      if (sale.status == 'returned') throw ArgumentError('Ye sale pehle hi return ho chuki hai');
      final itemRows = await txn.query('sale_items', where: 'invoice=?', whereArgs: [invoice]);
      final now = DateTime.now().millisecondsSinceEpoch;

      // Line amounts discount / rounding se PEHLE ke hain; refund bill total ke mutabiq (full return jaisa).
      final lineSum = itemRows.fold<double>(0, (sum, r) => sum + ((r['amount'] as num?)?.toDouble() ?? 0.0));
      final scale = lineSum > 0.009 ? sale.total / lineSum : 1.0;
      var partSum = 0.0;

      for (final r in itemRows) {
        final si = SaleItem.fromMap(r);
        final want = si.id == null ? null : requested[si.id!];
        if (want == null) continue;
        // NaN / Infinity UI se bypass ho kar aaye to bhi stock / balance kharab na ho.
        if (!want.isFinite) throw ArgumentError('Return ki miqdaar darust nahi');
        if (want <= 0) continue;
        final qty = want > si.qty ? si.qty : want;
        if (qty <= 0) continue;
        final frac = si.qty > 0 ? qty / si.qty : 1.0;

        final pr = await txn.query('products', where: 'barcode=?', whereArgs: [si.barcode], limit: 1);
        final product = pr.isEmpty ? null : Product.fromMap(pr.first);
        final smallest = saleItemSmallestQty(si, product) * frac;
        if (smallest > 0) {
          await _increaseStock(txn, si.barcode, smallest, now,
              type: MovementType.saleReversal, reference: invoice);
        }

        final part = si.amount * frac;
        final retAmount = lineSum > 0.009 ? part * scale : part;
        final ret = ReturnLine(
          reference: invoice,
          type: 'sale',
          barcode: si.barcode,
          qty: qty,
          amount: retAmount,
          createdAt: now,
        );
        final retId = await txn.insert('returns', ret.toMap());
        await _enqueueSync(txn, 'return', retId.toString(), 'create', ret.toMap());

        final remainingQty = si.qty - qty;
        if (remainingQty <= 0.0001) {
          await txn.delete('sale_items', where: 'id=?', whereArgs: [si.id]);
        } else {
          await txn.update(
            'sale_items',
            {
              'qty': remainingQty,
              'amount': si.amount - part,
              'cost': si.cost * (1 - frac),
              ...scaledPendingColumns(
                pendingQty: si.pendingQty,
                pendingEst: si.pendingEst,
                backfillLog: si.backfillLog,
                ratio: 1 - frac,
              ),
            },
            where: 'id=?',
            whereArgs: [si.id],
          );
        }
        returnedTotal += retAmount;
        partSum += part;
      }
      if (returnedTotal <= 0.009) {
        returnedTotal = 0;
        return;
      }

      final keep = lineSum > 0.009 ? ((lineSum - partSum) / lineSum).clamp(0.0, 1.0).toDouble() : 1.0;
      final newTotal = (sale.total - returnedTotal) < 0 ? 0.0 : (sale.total - returnedTotal);
      final newPaid = sale.paid.clamp(0.0, newTotal).toDouble();

      // Jo paisa ab bill se zyada hai wo wapas (dated cash-OUT): pehle bill ki apni cash rows, phir bill-linked payments.
      final refund = sale.paid - newPaid;
      if (refund > 0.009) {
        final own = await txn.rawQuery(
            'SELECT COALESCE(SUM(amount),0) AS s FROM cash_transactions WHERE reference = ?', [invoice]);
        final ownTotal = own.isEmpty ? 0.0 : ((own.first['s'] as num?)?.toDouble() ?? 0.0);
        final fromOwn = refund < ownTotal ? refund : ownTotal;
        await _reverseCash(txn, invoice, fromOwn, 'OUT', 'Sale Return', now);
        var left = refund - fromOwn;
        if (left > 0.009) {
          final linked = await txn.query('payments',
              where: 'billReference = ? AND reference != ?', whereArgs: [invoice, invoice]);
          for (final p in linked) {
            if (left <= 0.009) break;
            final amt = (p['amount'] as num?)?.toDouble() ?? 0.0;
            final cut = left < amt ? left : amt;
            if (cut <= 0.009) continue;
            await _reverseCash(txn, (p['reference'] as String?) ?? '', cut, 'OUT', 'Sale Return', now);
            if (amt - cut <= 0.009) {
              await SyncQueueHelper.deletePaymentRow(txn, Map<String, Object?>.from(p));
            } else {
              await txn.update('payments', {'amount': amt - cut, 'updatedAt': now, 'dirty': 1}, where: 'id = ?', whereArgs: [p['id']]);
              final fresh = (await txn.query('payments', where: 'id = ?', whereArgs: [p['id']], limit: 1)).first;
              await _enqueueSync(txn, 'payment', '${p['id']}', 'update', Map<String, Object?>.from(fresh));
            }
            left -= cut;
          }
        }
      }

      // Customer: sirf baqaya ka farq (poori return mein poora baqaya ulta hota hai).
      final delta = (newTotal - newPaid) - (sale.total - sale.paid);
      if (sale.customerId != null && delta.abs() > 0.009) {
        await _adjustCustomerBalance(txn, sale.customerId!, delta, now);
      }

      await txn.update(
        'sales',
        {
          'subtotal': sale.subtotal * keep,
          'discount': sale.discount * keep,
          'tax': sale.tax * keep,
          'total': newTotal,
          'paid': newPaid,
          'updatedAt': now,
          'dirty': 1,
        },
        where: 'invoice=?',
        whereArgs: [invoice],
      );
      final remainingCount = (await txn.rawQuery('SELECT COUNT(*) AS c FROM sale_items WHERE invoice=?', [invoice]))
              .first['c'] as int? ??
          0;
      await _enqueueSync(txn, 'sale', invoice, 'update', {
        'invoice': invoice,
        'customerId': sale.customerId,
        'total': newTotal,
        'paid': newPaid,
        'itemCount': remainingCount,
      });
    });

    await ProductRepository.instance.refresh();
    await CustomerRepository.instance.refresh();
    await _notify();
    if (returnedTotal > 0) await _logAudit('sale_return_partial', invoice, 'returned=$returnedTotal');
  }

  // --------------------------------------------------------- Customer's rate

  /// Last rate charged to [customerId] for [barcode] (most recent, returned
  /// sales excluded) — powers "use this customer's usual rate". Any DB error
  /// just means "no suggestion". Mirrors `lastRateForCustomerItem()`.
  Future<CustomerItemRate?> lastRateForCustomerItem(int customerId, String barcode) async {
    try {
      final db = await AppDatabase.instance.database;
      final rows = await db.rawQuery(
        'SELECT si.unitPrice AS unitPrice, si.unit AS unit, s.createdAt AS soldAt FROM sale_items si '
        'JOIN sales s ON si.invoice = s.invoice '
        "WHERE si.barcode = ? AND s.customerId = ? AND s.status != 'returned' "
        'ORDER BY s.createdAt DESC LIMIT 1',
        [barcode, customerId],
      );
      if (rows.isEmpty) return null;
      return CustomerItemRate(
        (rows.first['unitPrice'] as num).toDouble(),
        (rows.first['unit'] as String?) ?? '',
        (rows.first['soldAt'] as num?)?.toInt() ?? 0,
      );
    } catch (_) {
      return null;
    }
  }

  // ---------------------------------------------------------------- Quick Sale

  /// Mirrors `saveQuickSale()` (RoomSaleRepository): single item, retail,
  /// no discount. Blank customer = cash (fully paid); a name = 100% credit.
  /// Whole write path is one transaction. Throws [SaleStockException],
  /// [SaleCreditLimitException] (unless [overrideCreditLimit]) or
  /// [ArgumentError] for a bad qty/rate.
  Future<QuickSaleSaveResult> saveQuickSale({
    required Product product,
    required double qty,
    required double price,
    required String unit,
    required String customerName,
    bool overrideCreditLimit = false,
  }) async {
    if (!qty.isFinite || qty <= 0.0) throw ArgumentError('Qty finite aur 0 se zyada honi chahiye');
    if (!price.isFinite || price < 0.0) throw ArgumentError('Rate finite aur negative nahi ho sakta');

    final name = customerName.trim();
    final isCredit = name.isNotEmpty;
    // Bill total poore rupee par (nearest Rs), jaise saveSale() / DiscountCalculator.
    final amount = (qty * price).roundToDouble();
    if (!amount.isFinite) throw ArgumentError('Sale total finite hona chahiye');

    final db = await AppDatabase.instance.database;
    var resultInvoice = '';

    if (overrideCreditLimit && !await CreditOverridePolicy.currentUserMayOverride()) {
      throw ArgumentError('Credit limit se upar ka bill save karne ke liye admin ya manager ki ijazat zaroori hai.');
    }

    if (isCredit && !overrideCreditLimit) {
      final cr = await db.query('customers', where: 'LOWER(name) = ?', whereArgs: [name.toLowerCase()], limit: 1);
      if (cr.isNotEmpty) {
        final c = Customer.fromMap(cr.first);
        if (c.creditLimit > 0.0) {
          await _serverCreditCheck(
              customer: c,
              amount: amount,
              reservationId: 'qs:${DeviceTag.current}:${DateTime.now().microsecondsSinceEpoch}');
        }
      }
    }

    await db.transaction((txn) async {
      if (isCredit && !overrideCreditLimit) {
        final customerRows = await txn.query('customers', where: 'LOWER(name) = ?',
            whereArgs: [name.toLowerCase()], limit: 1);
        if (customerRows.isNotEmpty) {
          final existing = Customer.fromMap(customerRows.first);
          if (existing.creditLimit > 0.0) {
            final liveRunning = await PartyRepository.instance.liveCustomerBalanceIn(txn, existing.id!);
            final projected = partyClosing(opening: existing.openingBalance, running: liveRunning,
                stuck: existing.stuckBalance) + amount;
            if (projected > existing.creditLimit + 0.009) {
              throw SaleCreditLimitException(existing.name, existing.creditLimit, projected);
            }
          }
        }
      }

      final rows = await txn.query('products', where: 'barcode=?', whereArgs: [product.barcode], limit: 1);
      if (rows.isEmpty) throw SaleStockException('Stock badal gaya hai, dobara try karen');
      final current = Product.fromMap(rows.first);
      final smallest = current.toSmallestUnits(qty, unit);
      if (!hasEnoughStock(current.stock, smallest) && !await StockPolicy.readFrom(txn)) {
        throw SaleStockException('Stock badal gaya hai, dobara try karen');
      }
      if (!current.isValidSmallestQty(smallest)) {
        throw ArgumentError('Qty ($qty $unit) whole ${current.smallestUnitName()} mein convert nahi hoti');
      }

      final now = DateTime.now().millisecondsSinceEpoch;
      int? customerId;
      if (isCredit) {
        final custRows = await txn.query('customers', where: 'LOWER(name)=?', whereArgs: [name.toLowerCase()], limit: 1);
        if (custRows.isNotEmpty) {
          customerId = custRows.first['id'] as int;
        } else {
          customerId = await txn.insert('customers', {
            'name': name,
            'phone': '',
            'creditLimit': 0.0,
            'openingBalance': 0.0,
            'balance': 0.0,
            'updatedAt': now,
            'dirty': 1,
          });
          await SyncQueueHelper.enqueueCustomer(txn, customerId);
        }
      }

      final factor = current.smallestUnitFactor();
      final costPerSmallest = costPerSmallestOf(current.cost, factor);
      final lineCost = smallest * costPerSmallest;
      // costPending: stock se na dhaka hissa (ya cost 0) — purchase aane par asal cost bhari jayegi.
      final quickPending = CostBackfill.pendingForSale(
        needed: smallest,
        stockBefore: current.stock,
        costPerSmallest: costPerSmallest,
        lineCost: lineCost,
      );

      final invoice = nextInvoiceNumber(now);
      final dup = await txn.query('sales', where: 'invoice=?', whereArgs: [invoice], limit: 1);
      if (dup.isNotEmpty) {
        throw SaleStockException('Invoice number "$invoice" pehle se mojood hai. Dobara try karen.');
      }

      final paid = isCredit ? 0.0 : amount;
      final method = isCredit ? 'credit' : 'cash';

      await txn.insert(
        'sales',
        Sale(
          invoice: invoice,
          customerId: customerId,
          subtotal: amount,
          discount: 0.0,
          tax: 0.0,
          total: amount,
          paid: paid,
          paymentMethod: method,
          saleType: 'retail',
          createdAt: now,
          updatedAt: now,
        ).toMap(),
      );
      await txn.insert('sale_items', {
        'invoice': invoice,
        'barcode': current.barcode,
        'product': current.name,
        'qty': qty,
        'unit': unit,
        'unitPrice': price,
        'cost': lineCost,
        'amount': amount,
        'conversionFactor': current.smallestPerUnitOf(unit),
        'pendingQty': quickPending.pendingQty,
        'pendingEst': quickPending.pendingEst,
      });

      await txn.rawUpdate(
        'UPDATE products SET stock = stock - ?, dirty = 1, updatedAt = ? WHERE barcode = ?',
        [smallest, now, current.barcode],
      );
      await SyncQueueHelper.enqueueStockDelta(txn, current.barcode, -smallest);
      await StockLedger.log(txn,
          barcode: current.barcode, type: MovementType.sale, signedQty: -smallest, reference: invoice, now: now);
      if (isCredit && customerId != null) {
        await txn.rawUpdate('UPDATE customers SET balance = balance + ?, dirty = 1 WHERE id = ?', [amount, customerId]);
        await SyncQueueHelper.enqueueBalanceDelta(txn, customer: true, partyId: customerId, delta: amount);
      }

      await _enqueueSync(txn, 'sale', invoice, 'create', {
        'invoice': invoice,
        'customerId': customerId,
        'total': amount,
        'paid': paid,
        'itemCount': 1,
        'quick': true,
      });

      if (paid > 0) {
        final cashTx = CashTransaction(
          type: 'IN',
          method: method,
          amount: paid,
          reason: 'Quick Sale',
          reference: invoice,
          createdAt: now,
        );
        final id = await txn.insert('cash_transactions', cashTx.toMap());
        await _enqueueSync(txn, 'cash_transaction', id.toString(), 'create', cashTx.toMap());
      }
      resultInvoice = invoice;
    });

    await ProductRepository.instance.refresh();
    await CustomerRepository.instance.refresh();
    await _notify();
    return QuickSaleSaveResult(resultInvoice, isCredit);
  }

  /// Best-selling product names over the last 30 days (top 5), used to put
  /// them first in the Quick Sale item list. Mirrors `topProductNames()`;
  /// any DB error just returns an empty list, like the Kotlin version.
  Future<List<String>> topProductNames() async {
    try {
      final db = await AppDatabase.instance.database;
      final now = DateTime.now().millisecondsSinceEpoch;
      final since = now - const Duration(days: 30).inMilliseconds;
      final rows = await db.rawQuery(
        "SELECT product, SUM(qty) AS totalQty FROM sale_items "
        "WHERE invoice IN (SELECT invoice FROM sales WHERE createdAt BETWEEN ? AND ? AND status != 'returned') "
        "GROUP BY product ORDER BY totalQty DESC LIMIT 5",
        [since, now],
      );
      return rows.map((r) => r['product'] as String).toList();
    } catch (_) {
      return const [];
    }
  }

  // ------------------------------------------------------------ Hold / Recall

  /// Sale holds only (`HOLD...`), newest first. Purchase holds (`PHOLD...`)
  /// live in the same table and must never show up here.
  Future<List<HeldBill>> heldBills() async {
    final db = await AppDatabase.instance.database;
    final rows = await db.query(
      'held_bills',
      where: "holdId LIKE 'HOLD%'",
      orderBy: 'createdAt DESC',
    );
    return rows.map(HeldBill.fromMap).toList();
  }

  /// Mirrors HoldBillUseCase: id = "HOLD" + millis.
  Future<void> holdBill(String payload) async {
    final db = await AppDatabase.instance.database;
    final now = DateTime.now().millisecondsSinceEpoch;
    await db.insert('held_bills', HeldBill(holdId: 'HOLD$now', payload: payload, createdAt: now).toMap());
  }

  Future<void> deleteHeldBill(HeldBill bill) async {
    final db = await AppDatabase.instance.database;
    await db.delete('held_bills', where: 'holdId=?', whereArgs: [bill.holdId]);
  }

  /// SyncQueueHelper.enqueueLegacy: asal payload DB se (Android shape) — hamesha data likhne ke BAAD.
  Future<void> _enqueueSync(Transaction txn, String entityType, String entityId, String operation,
          Map<String, Object?> payload) =>
      SyncQueueHelper.enqueueLegacy(txn, entityType, entityId, operation, payload);

  String _trimNum(double v) => v == v.truncateToDouble() ? v.toInt().toString() : v.toString();
}

extension _FirstOrNull<T> on Iterable<T> {
  T? get firstOrNull => isEmpty ? null : first;
}
