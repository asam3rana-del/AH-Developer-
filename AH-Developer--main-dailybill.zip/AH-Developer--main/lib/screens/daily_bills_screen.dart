import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:share_plus/share_plus.dart';

import '../db/daily_bills_repository.dart';
import '../theme/theme_manager.dart';
import '../utils/loc.dart';
import '../utils/sale_cart.dart' show formatQty;
import '../widgets/premium_header.dart';
import '../widgets/role_guard.dart';

/// "Aaj ke Bills" — ek din ki saari alag alag (Quick Sale) sales har customer ke ek bill ki tarah,
/// saath mein pichla balance aur aaj ka balance. Sales/stock/balance ko koi tabdeeli nahi: sirf dikhana,
/// share aur print.
class DailyBillsScreen extends StatelessWidget {
  const DailyBillsScreen({super.key});

  @override
  Widget build(BuildContext context) =>
      const RoleGuard(allowed: {'admin', 'manager'}, child: _DailyBillsBody());
}

class _DailyBillsBody extends StatefulWidget {
  const _DailyBillsBody();

  @override
  State<_DailyBillsBody> createState() => _DailyBillsBodyState();
}

class _DailyBillsBodyState extends State<_DailyBillsBody> {
  DateTime _day = DateTime.now();
  bool _loading = true;
  List<DailyParty> _rows = const [];

  final _dateFmt = DateFormat('dd MMM yyyy');
  final _timeFmt = DateFormat('hh:mm a');

  AppPalette get _p => ThemeManager.palette;
  String _rs(double v) => 'Rs ${v.toStringAsFixed(v == v.roundToDouble() ? 0 : 2)}';
  Color _balColor(double v) => v < 0 ? _p.red : _p.flatTealFg;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    List<DailyParty> rows;
    try {
      rows = await DailyBillsRepository.instance.loadDay(_day);
    } catch (_) {
      rows = const [];
    }
    if (!mounted) return;
    setState(() {
      _rows = rows;
      _loading = false;
    });
  }

  void _shift(int days) {
    setState(() => _day = DateTime(_day.year, _day.month, _day.day + days));
    _load();
  }

  Future<void> _pickDate() async {
    final d = await showDatePicker(
      context: context,
      initialDate: _day,
      firstDate: DateTime(2020),
      lastDate: DateTime.now().add(const Duration(days: 1)),
    );
    if (d == null) return;
    setState(() => _day = d);
    _load();
  }

  bool get _isToday {
    final n = DateTime.now();
    return n.year == _day.year && n.month == _day.month && n.day == _day.day;
  }

  @override
  Widget build(BuildContext context) {
    final totalSales = _rows.fold<double>(0, (a, r) => a + r.salesTotal);
    final totalReceived = _rows.fold<double>(0, (a, r) => a + r.receivedTotal);
    return Scaffold(
      backgroundColor: _p.bg,
      appBar: AppBar(backgroundColor: _p.navy, foregroundColor: Colors.white, elevation: 0),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(12, 10, 12, 30),
          children: [
            PremiumHeader(
              title: Loc.t('Daily Bills', 'روزانہ بلز'),
              subtitle: Loc.t('Har customer ka din ka ek bill + balance', 'ہر کسٹمر کا دن کا ایک بل اور بیلنس'),
            ),
            _dateBar(),
            if (!_loading && _rows.isNotEmpty) _summary(totalSales, totalReceived),
            if (_loading)
              const Padding(padding: EdgeInsets.all(30), child: Center(child: CircularProgressIndicator()))
            else if (_rows.isEmpty)
              Padding(
                padding: const EdgeInsets.all(30),
                child: Center(
                  child: Text(Loc.t('Is din koi sale nahi', 'اس دن کوئی سیل نہیں'),
                      style: TextStyle(color: _p.textMuted, fontWeight: FontWeight.bold)),
                ),
              )
            else
              for (final r in _rows) _partyCard(r),
          ],
        ),
      ),
    );
  }

  Widget _dateBar() => Container(
        margin: const EdgeInsets.only(bottom: 10),
        decoration: BoxDecoration(
          color: _p.cardWhite,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: _p.border),
        ),
        child: Row(children: [
          IconButton(icon: const Icon(Icons.chevron_left), onPressed: () => _shift(-1)),
          Expanded(
            child: InkWell(
              onTap: _pickDate,
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 12),
                child: Text(
                  '${_isToday ? '${Loc.t('Aaj', 'آج')} • ' : ''}${_dateFmt.format(_day)}',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: _p.textDark),
                ),
              ),
            ),
          ),
          IconButton(icon: const Icon(Icons.chevron_right), onPressed: _isToday ? null : () => _shift(1)),
        ]),
      );

  Widget _summary(double sales, double received) => Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: _p.cardWhite,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: _p.border),
        ),
        child: Row(children: [
          _stat(Loc.t('Customers', 'کسٹمرز'), '${_rows.length}', _p.textDark),
          _stat(Loc.t('Kul sale', 'کل سیل'), _rs(sales), _p.flatBlueFg),
          _stat(Loc.t('Kul mila', 'کل وصول'), _rs(received), _p.flatTealFg),
        ]),
      );

  Widget _stat(String label, String value, Color color) => Expanded(
        child: Column(children: [
          Text(label, style: TextStyle(fontSize: 11.5, color: _p.textMuted)),
          const SizedBox(height: 3),
          Text(value, style: TextStyle(fontSize: 14.5, fontWeight: FontWeight.bold, color: color)),
        ]),
      );

  Widget _kv(String k, String v, {Color? color, bool bold = false}) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 2.5),
        child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text(k, style: TextStyle(fontSize: 13, color: _p.textMuted, fontWeight: bold ? FontWeight.bold : FontWeight.normal)),
          Text(v, style: TextStyle(fontSize: 13.5, fontWeight: FontWeight.bold, color: color ?? _p.textDark)),
        ]),
      );

  Widget _partyCard(DailyParty r) => Container(
        margin: const EdgeInsets.only(bottom: 10),
        decoration: BoxDecoration(
          color: _p.cardWhite,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: _p.border),
          boxShadow: const [BoxShadow(color: Color(0x0F000000), blurRadius: 4, offset: Offset(0, 1))],
        ),
        child: InkWell(
          borderRadius: BorderRadius.circular(18),
          onTap: () => _showDetail(r),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
            child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              Row(children: [
                Expanded(
                  child: Text(r.name, style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: _p.textDark)),
                ),
                Text('${r.billCount} ${Loc.t('bills', 'بلز')}', style: TextStyle(fontSize: 12, color: _p.textMuted)),
              ]),
              const SizedBox(height: 8),
              _kv(Loc.t('Pichla balance', 'پچھلا بیلنس'), _rs(r.previousBalance), color: _balColor(r.previousBalance)),
              _kv(Loc.t('Aaj ki sale', 'آج کی سیل'), '+ ${_rs(r.salesTotal)}', color: _p.flatBlueFg),
              if (r.receivedTotal > 0)
                _kv(Loc.t('Aaj mila', 'آج وصول'), '- ${_rs(r.receivedTotal)}', color: _p.flatTealFg),
              Divider(height: 14, color: _p.border),
              _kv(Loc.t('Aaj ka balance', 'آج کا بیلنس'), _rs(r.closingBalance), color: _balColor(r.closingBalance), bold: true),
            ]),
          ),
        ),
      );

  // ---- detail: ek customer ka poora din ka bill -------------------------------------------

  Future<void> _showDetail(DailyParty r) async {
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: _p.cardWhite,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(22))),
      builder: (ctx) => DraggableScrollableSheet(
        expand: false,
        initialChildSize: 0.85,
        maxChildSize: 0.95,
        builder: (_, scroll) => ListView(
          controller: scroll,
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
          children: [
            Text(r.name, style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold, color: _p.textDark)),
            Text(_dateFmt.format(_day), style: TextStyle(color: _p.textMuted)),
            const SizedBox(height: 10),
            _kv(Loc.t('Pichla balance', 'پچھلا بیلنس'), _rs(r.previousBalance), color: _balColor(r.previousBalance), bold: true),
            Divider(color: _p.border),
            for (final b in r.bills) ...[
              Row(children: [
                Expanded(
                  child: Text('${b.invoice}  •  ${_timeFmt.format(DateTime.fromMillisecondsSinceEpoch(b.time))}',
                      style: TextStyle(fontWeight: FontWeight.bold, color: _p.textDark)),
                ),
                Text(_rs(b.total), style: TextStyle(fontWeight: FontWeight.bold, color: _p.flatBlueFg)),
              ]),
              for (final i in b.items)
                Padding(
                  padding: const EdgeInsets.only(left: 8, top: 2),
                  child: Row(children: [
                    Expanded(
                      child: Text(
                        '${i.product}  ${formatQty(i.qty)}${i.unit.isEmpty ? '' : ' ${i.unit}'} × ${i.unitPrice.toStringAsFixed(i.unitPrice == i.unitPrice.roundToDouble() ? 0 : 2)}',
                        style: TextStyle(fontSize: 12.5, color: _p.textMuted),
                      ),
                    ),
                    Text(i.amount.toStringAsFixed(i.amount == i.amount.roundToDouble() ? 0 : 2),
                        style: TextStyle(fontSize: 12.5, color: _p.textDark)),
                  ]),
                ),
              if (b.paid > 0)
                Padding(
                  padding: const EdgeInsets.only(left: 8, top: 2),
                  child: Text('${Loc.t('Paid', 'ادا')}: ${_rs(b.paid)}',
                      style: TextStyle(fontSize: 12.5, color: _p.flatTealFg)),
                ),
              Divider(color: _p.border),
            ],
            for (final pm in r.payments)
              _kv('${Loc.t('Payment mili', 'ادائیگی ملی')} • ${_timeFmt.format(DateTime.fromMillisecondsSinceEpoch(pm.time))}',
                  '- ${_rs(pm.amount)}', color: _p.flatTealFg),
            _kv(Loc.t('Aaj ki sale', 'آج کی سیل'), '+ ${_rs(r.salesTotal)}', color: _p.flatBlueFg),
            if (r.receivedTotal > 0) _kv(Loc.t('Aaj mila', 'آج وصول'), '- ${_rs(r.receivedTotal)}', color: _p.flatTealFg),
            Divider(color: _p.border),
            _kv(Loc.t('Aaj ka balance', 'آج کا بیلنس'), _rs(r.closingBalance), color: _balColor(r.closingBalance), bold: true),
            const SizedBox(height: 14),
            Row(children: [
              Expanded(
                child: FilledButton.icon(
                  style: FilledButton.styleFrom(backgroundColor: _p.flatTealFg, padding: const EdgeInsets.symmetric(vertical: 13)),
                  onPressed: () => Share.share(dailyBillText(r, _day)),
                  icon: const Icon(Icons.share),
                  label: Text(Loc.t('Share bill', 'بل شیئر کریں')),
                ),
              ),
            ]),
          ],
        ),
      ),
    );
  }
}
