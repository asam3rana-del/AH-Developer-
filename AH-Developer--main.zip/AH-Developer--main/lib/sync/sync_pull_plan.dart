import 'sync_push_plan.dart' show asMillis;
import 'sync_types.dart';

/// SyncApi.pull ka SAAF hissa (Firestore ke baghair) — Kotlin `pull()` ke aakhri hisse.

/// Pull har baar checkpoint se itna pichhe se shuru hota hai (late-push / thora clock farq ke docs na chhoote).
/// Apply idempotent hai, is liye dobara pull nuqsan nahi karta.
const int pullOverlapMs = 10 * 60 * 1000;

/// Stock / balance wali collections (products, customers, suppliers) ka overlap bada. `updatedAt` PUSH karne
/// wale device ki apni clock se banta hai: kisi device ki clock peeche ho to uski stock/balance change doosre
/// device ke checkpoint se purani nazar aati thi aur kabhi pull nahi hoti thi (stock/balance hamesha alag).
/// 1 ghante ke andar badle hue docs har sync par dobara aate hain; apply idempotent hai (cloud + local pending),
/// is liye dobara lagana nuqsan nahi karta. (Firestore reads ka khayal: 1 ghanta, 24 nahi.)
const int stockPullOverlapMs = 60 * 60 * 1000;

/// Un collections ke naam jin par [stockPullOverlapMs] lagta hai.
const Set<String> stockPullCollections = {'products', 'customers', 'suppliers'};

/// Kotlin `pull()` ki tarteeb mein 20 collections + Flutter ki 4 Workers + 2 Shop Rents + 2 Utility Bills collections (Firestore naam).
const List<String> pullCollections = [
  'customers',
  'suppliers',
  'products',
  'users',
  'sales',
  'purchases',
  'payments',
  'expenses',
  'cash_transactions',
  'units',
  'categories',
  'zakat_years',
  'zakat_payments',
  'returns',
  'stock_movements',
  'app_settings',
  'cash_register',
  'shell_customers',
  'shell_transactions',
  'shop_empty_shell_log',
  'workers',
  'worker_attendance',
  'worker_advances',
  'worker_salary_payments',
  'shop_rents',
  'shop_rent_ledger',
  'utility_bills',
  'utility_bill_payments',
];

/// Har collection ke documents (`byCollection[collectionName]`) se `PullResult` banao.
/// `serverTime` = sab documents mein sab se bara numeric `updatedAt` (kam az kam `since`) — agli pull
/// ka checkpoint. `updatedAt` ke baghair document checkpoint ko nahi badhata (Kotlin `?: continue`).
PullResult assemblePullResult(Map<String, List<SyncDoc>> byCollection, int since, {int? nowMs}) {
  List<SyncDoc> of(String c) => byCollection[c] ?? const [];
  // Kisi device ki clock aage ho to uska updatedAt checkpoint ko future mein na dhakele (warna baqi
  // devices darmiyan ke naye docs kabhi pull nahi karte): checkpoint 'ab + 5 min' se aage nahi jata.
  final ceiling = (nowMs ?? DateTime.now().millisecondsSinceEpoch) + 5 * 60 * 1000;
  var maxUpdatedAt = since;
  for (final c in pullCollections) {
    for (final d in of(c)) {
      final t = asMillis(d['updatedAt']);
      if (t != null && t > maxUpdatedAt) maxUpdatedAt = t > ceiling ? (ceiling > since ? ceiling : since) : t;
    }
  }
  return PullResult(
    customers: of('customers'),
    suppliers: of('suppliers'),
    products: of('products'),
    users: of('users'),
    sales: of('sales'),
    purchases: of('purchases'),
    payments: of('payments'),
    expenses: of('expenses'),
    cashTransactions: of('cash_transactions'),
    units: of('units'),
    categories: of('categories'),
    zakatYears: of('zakat_years'),
    zakatPayments: of('zakat_payments'),
    returns: of('returns'),
    stockMovements: of('stock_movements'),
    appSettings: of('app_settings'),
    cashRegisters: of('cash_register'),
    shellCustomers: of('shell_customers'),
    shellTransactions: of('shell_transactions'),
    shopEmptyShellLogs: of('shop_empty_shell_log'),
    workers: of('workers'),
    workerAttendance: of('worker_attendance'),
    workerAdvances: of('worker_advances'),
    workerSalaryPayments: of('worker_salary_payments'),
    shopRents: of('shop_rents'),
    shopRentEntries: of('shop_rent_ledger'),
    utilityBills: of('utility_bills'),
    utilityBillPayments: of('utility_bill_payments'),
    serverTime: maxUpdatedAt,
  );
}

/// Kotlin `SyncApi.BRANCH_SCOPED_COLLECTIONS` — ghalat/foreign branchId cleanup (count/delete) in hi
/// collections par chalta hai. Jaan boojh kar `users` (login/permission data) aur shell_* shamil NAHI
/// (Kotlin jaisa).
const List<String> branchScopedCollections = [
  'customers',
  'suppliers',
  'products',
  'sales',
  'purchases',
  'payments',
  'expenses',
  'cash_transactions',
  'units',
  'categories',
  'zakat_years',
  'zakat_payments',
  'returns',
  'stock_movements',
  'app_settings',
  'cash_register',
  'workers',
  'worker_attendance',
  'worker_advances',
  'worker_salary_payments',
  'shop_rents',
  'shop_rent_ledger',
  'utility_bills',
  'utility_bill_payments',
];

/// Firestore batch delete ka hissa (limit 500 se neeche) — Kotlin `.limit(400)`.
const int branchCleanupBatchSize = 400;
