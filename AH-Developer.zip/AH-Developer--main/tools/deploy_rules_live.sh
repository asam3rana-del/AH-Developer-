#!/data/data/com.termux/files/usr/bin/env bash
# Hanna POS: LIVE Firestore rules — device roles (cashier server par roka jata hai).
#   bash /sdcard/Download/deploy_rules_live.sh            -> device-roles rules publish
#   bash /sdcard/Download/deploy_rules_live.sh rollback   -> purani (sirf branch) rules wapas
# Role na likha ho = admin (aaj jaisa). Sirf branch_members/{uid}.role = "cashier" wale devices par pabandi.
set -e
MODE="${1:-roles}"
PROJECT="${2:-my-grocery-pos-8a444}"
command -v firebase >/dev/null 2>&1 || { echo "firebase CLI nahi mila"; exit 1; }
WORK="$HOME/ah_rules_deploy"
rm -rf "$WORK" && mkdir -p "$WORK" && cd "$WORK"
printf '{\n  "firestore": { "rules": "firestore.rules" }\n}\n' > firebase.json
if [ "$MODE" = "rollback" ]; then
cat > firestore.rules <<'AHRULES_EOF'
rules_version = '2';

// Baseline rules for the shared multi-branch Firestore project.
//
// What this enforces:
//   - Nobody unauthenticated can read or write anything (blocks the public-internet
//     default-deny gap that an empty/missing rules file would otherwise leave open).
//   - Every write to a synced collection must carry a non-empty "branchId" field that
//     matches the document's existing branchId (so a client can't silently switch a
//     record from one branch to another, and can't write a document with no branchId
//     at all going forward).
//   - A signed-in user may only read/create/update/delete documents whose branchId
//     matches THEIR OWN branch, per the server-side branch_members/{uid} mapping —
//     not whatever branchId their client's BuildConfig happens to send. This closes
//     the gap where a modified/rogue client could claim any branchId.
//   - branch_members/{uid} itself is never writable by clients (admin/console only),
//     so a user cannot grant themselves access to another branch.
//
// Setup required before deploying:
//   Create one document per staff member at branch_members/{uid} with the shape
//   { branchId: "dusri-branch" }, where {uid} is that user's Firebase Auth UID
//   (via Firebase console or a small admin script — NOT from the app itself).
service cloud.firestore {
  match /databases/{database}/documents {

    function isSignedIn() {
      return request.auth != null;
    }

    // The branch this signed-in user is provisioned for, per server-side mapping.
    function myBranchId() {
      return get(/databases/$(database)/documents/branch_members/$(request.auth.uid)).data.branchId;
    }

    function isMyBranch(branchId) {
      return isSignedIn()
          && exists(/databases/$(database)/documents/branch_members/$(request.auth.uid))
          && branchId == myBranchId();
    }

    // Reads of a document that does not exist yet (resource == null) must not error out:
    // the sync push reads each doc inside a transaction before creating it, and
    // resource.data.* on a missing doc makes the rule fail with PERMISSION_DENIED.
    // A provisioned member may read "nothing"; an existing doc must be in their branch.
    function canRead() {
      return isSignedIn()
          && exists(/databases/$(database)/documents/branch_members/$(request.auth.uid))
          && (resource == null || resource.data.branchId == myBranchId());
    }

    function hasBranchId() {
      return request.resource.data.branchId is string
          && request.resource.data.branchId.size() > 0;
    }

    function branchIdUnchanged() {
      return !resource.data.keys().hasAny(['branchId'])
          || request.resource.data.branchId == resource.data.branchId;
    }

    // FIX (missing collections — Zakat/Units/Categories/Returns/Stock/App Settings
    // couldn't actually sync): SyncApi.kt has synced these collections for a while
    // (see its class doc comment at the top of that file), but this allowlist was
    // never updated to match — so every push/pull for units, categories, zakat
    // years/payments, returns, stock_movements, and app_settings was being silently
    // rejected by these rules with PERMISSION_DENIED, even though the app-side sync
    // code for them was working correctly. Added here so they actually reach
    // Firestore like every other synced entity.
    function isSyncedCollection(collection) {
      return collection in ['customers', 'suppliers', 'products', 'users',
                             'sales', 'purchases', 'payments', 'expenses',
                             'cash_transactions', 'cash_register',
                             'units', 'categories', 'zakat_years', 'zakat_payments',
                             'returns', 'stock_movements', 'app_settings',
                             'shell_customers', 'shell_transactions', 'shop_empty_shell_log',
                             'workers', 'worker_attendance', 'worker_advances',
                             'worker_salary_payments', 'shop_rents', 'shop_rent_ledger',
                             'utility_bills', 'utility_bill_payments'];
    }

    // Server-side record of which branch each staff UID belongs to.
    // Clients can read only their own membership doc; never write.
    match /branch_members/{uid} {
      allow read: if isSignedIn() && request.auth.uid == uid;
      allow write: if false;
    }

    // Due Reminders follow-up log (collection due_followups): same branch rules as every
    // synced collection, plus field validation. due_followups is deliberately NOT in
    // isSyncedCollection() above — Firestore ORs matching rules, so leaving it there would
    // let the generic rule below bypass validFollowup().
    function validFollowup() {
      let d = request.resource.data;
      return hasBranchId()
          && d.method in ['whatsapp', 'call', 'visit', 'sms', 'note']
          && d.outcome in ['sent', 'paid', 'promised', 'partial',
                           'no_answer', 'refused', 'dispute', 'note']
          && (d.get('amount', null) == null || (d.amount is number && d.amount >= 0))
          && (d.get('promiseDate', null) == null || d.promiseDate is number)
          && (d.get('nextFollowUp', null) == null || d.nextFollowUp is number)
          && (!('note' in d) || d.note == null || (d.note is string && d.note.size() <= 500));
    }

    match /due_followups/{docId} {
      allow read: if canRead();
      allow create: if isMyBranch(request.resource.data.branchId) && validFollowup();
      allow update: if isMyBranch(resource.data.branchId)
                     && branchIdUnchanged() && validFollowup();
      allow delete: if isMyBranch(resource.data.branchId);
    }

    match /{collection}/{docId} {
      allow read: if isSyncedCollection(collection) && canRead();
      allow create: if isSignedIn() && isSyncedCollection(collection)
                     && hasBranchId() && isMyBranch(request.resource.data.branchId);
      allow update: if isSignedIn() && isSyncedCollection(collection)
                     && hasBranchId() && branchIdUnchanged()
                     && isMyBranch(resource.data.branchId);
      allow delete: if isSignedIn() && isSyncedCollection(collection)
                     && isMyBranch(resource.data.branchId);
    }

    // Crash reports: app ki ghalti (stack trace) developer ko — sirf banana, branch member device, chhota text,
    // apna uid. Padhna / badalna / mitana app se nahi (sirf Firebase console). lib/services/crash_reporter.dart.
    match /crash_reports/{docId} {
      allow create: if isSignedIn()
                    && exists(/databases/$(database)/documents/branch_members/$(request.auth.uid))
                    && request.resource.data.keys().hasOnly(['text', 'at', 'device', 'branchId', 'app', 'uid'])
                    && request.resource.data.text is string
                    && request.resource.data.text.size() <= 8000
                    && request.resource.data.uid == request.auth.uid;
      allow read, update, delete: if false;
    }

    // Deny everything else by default.
    match /{document=**} {
      allow read, write: if false;
    }
  }
}
AHRULES_EOF
  echo "ROLLBACK: purani branch-only rules -> $PROJECT"
else
cat > firestore.rules <<'AHRULES_EOF'
rules_version = '2';

// DEVICE ROLES (no Cloud Functions / no billing card needed).
// Same as firestore.rules, plus an OPTIONAL `role` field on each device's branch_members/{uid} document, set by
// the owner in the Firebase console (admin | manager | cashier). A document WITHOUT `role` behaves exactly like
// today (full access), so rolling this out cannot break an existing device; only devices you mark
// role = "cashier" are restricted:
//   - read only the till collections (no users / suppliers / purchases / payroll / rent / utility / zakat)
//   - create/update only sales, payments, expenses, cash, returns, stock movements, shell, customers, cash_register,
//     due_followups; products only stock/updatedAt/appliedOps (increments), customers never creditLimit /
//     openingBalance / stuckBalance
//   - never delete and never write a tombstone (_deleted: true) - this app deletes by tombstone, not real delete
// The role belongs to the DEVICE (its anonymous UID), not to a person. Clients cannot write branch_members.
// Residual risk: a modified cashier app can still write wrong amounts inside its own branch (rules cannot
// validate a sale against its stock / balance changes) and can read product cost.

// Baseline rules for the shared multi-branch Firestore project.
//
// What this enforces:
//   - Nobody unauthenticated can read or write anything (blocks the public-internet
//     default-deny gap that an empty/missing rules file would otherwise leave open).
//   - Every write to a synced collection must carry a non-empty "branchId" field that
//     matches the document's existing branchId (so a client can't silently switch a
//     record from one branch to another, and can't write a document with no branchId
//     at all going forward).
//   - A signed-in user may only read/create/update/delete documents whose branchId
//     matches THEIR OWN branch, per the server-side branch_members/{uid} mapping —
//     not whatever branchId their client's BuildConfig happens to send. This closes
//     the gap where a modified/rogue client could claim any branchId.
//   - branch_members/{uid} itself is never writable by clients (admin/console only),
//     so a user cannot grant themselves access to another branch.
//
// Setup required before deploying:
//   Create one document per staff member at branch_members/{uid} with the shape
//   { branchId: "dusri-branch" }, where {uid} is that user's Firebase Auth UID
//   (via Firebase console or a small admin script — NOT from the app itself).
service cloud.firestore {
  match /databases/{database}/documents {

    function isSignedIn() {
      return request.auth != null;
    }

    // The branch this signed-in user is provisioned for, per server-side mapping.
    function myBranchId() {
      return get(/databases/$(database)/documents/branch_members/$(request.auth.uid)).data.branchId;
    }

    function isMyBranch(branchId) {
      return isSignedIn()
          && exists(/databases/$(database)/documents/branch_members/$(request.auth.uid))
          && branchId == myBranchId();
    }

    // Role of this device ('admin' when the field is missing = today's behaviour). Only call after membership exists.
    function myRole() {
      return get(/databases/$(database)/documents/branch_members/$(request.auth.uid)).data.get('role', 'admin');
    }
    function isCashier() { return myRole() == 'cashier'; }

    function notTombstone() { return request.resource.data.get('_deleted', false) != true; }
    function changedKeys() { return request.resource.data.diff(resource.data).affectedKeys(); }

    function cashierReadable(collection) {
      return collection in ['customers', 'products', 'sales', 'payments', 'expenses', 'cash_transactions',
                            'cash_register', 'units', 'categories', 'returns', 'stock_movements',
                            'app_settings', 'shell_customers', 'shell_transactions', 'shop_empty_shell_log'];
    }
    function cashierMayCreate(collection) {
      return notTombstone() && collection in ['customers', 'sales', 'payments', 'expenses', 'cash_transactions',
                            'cash_register', 'returns', 'stock_movements', 'shell_customers',
                            'shell_transactions', 'shop_empty_shell_log'];
    }
    function cashierMayUpdate(collection) {
      return notTombstone() && (
        (collection == 'products'
          && changedKeys().hasOnly(['stock', 'updatedAt', 'branchId', 'appliedOps', 'serverId', 'pushedAt']))
        || (collection == 'customers'
          && !changedKeys().hasAny(['creditLimit', 'openingBalance', 'stuckBalance', '_deleted']))
        || collection in ['sales', 'payments', 'expenses', 'cash_transactions', 'cash_register', 'returns',
                          'stock_movements', 'shell_customers', 'shell_transactions', 'shop_empty_shell_log']);
    }

    // Reads of a document that does not exist yet (resource == null) must not error out:
    // the sync push reads each doc inside a transaction before creating it, and
    // resource.data.* on a missing doc makes the rule fail with PERMISSION_DENIED.
    // A provisioned member may read "nothing"; an existing doc must be in their branch.
    function canRead() {
      return isSignedIn()
          && exists(/databases/$(database)/documents/branch_members/$(request.auth.uid))
          && (resource == null || resource.data.branchId == myBranchId());
    }

    function hasBranchId() {
      return request.resource.data.branchId is string
          && request.resource.data.branchId.size() > 0;
    }

    function branchIdUnchanged() {
      return !resource.data.keys().hasAny(['branchId'])
          || request.resource.data.branchId == resource.data.branchId;
    }

    // FIX (missing collections — Zakat/Units/Categories/Returns/Stock/App Settings
    // couldn't actually sync): SyncApi.kt has synced these collections for a while
    // (see its class doc comment at the top of that file), but this allowlist was
    // never updated to match — so every push/pull for units, categories, zakat
    // years/payments, returns, stock_movements, and app_settings was being silently
    // rejected by these rules with PERMISSION_DENIED, even though the app-side sync
    // code for them was working correctly. Added here so they actually reach
    // Firestore like every other synced entity.
    function isSyncedCollection(collection) {
      return collection in ['customers', 'suppliers', 'products', 'users',
                             'sales', 'purchases', 'payments', 'expenses',
                             'cash_transactions', 'cash_register',
                             'units', 'categories', 'zakat_years', 'zakat_payments',
                             'returns', 'stock_movements', 'app_settings',
                             'shell_customers', 'shell_transactions', 'shop_empty_shell_log',
                             'workers', 'worker_attendance', 'worker_advances',
                             'worker_salary_payments', 'shop_rents', 'shop_rent_ledger',
                             'utility_bills', 'utility_bill_payments'];
    }

    // Server-side record of which branch each staff UID belongs to.
    // Clients can read only their own membership doc; never write.
    match /branch_members/{uid} {
      allow read: if isSignedIn() && request.auth.uid == uid;
      allow write: if false;
    }

    // Due Reminders follow-up log (collection due_followups): same branch rules as every
    // synced collection, plus field validation. due_followups is deliberately NOT in
    // isSyncedCollection() above — Firestore ORs matching rules, so leaving it there would
    // let the generic rule below bypass validFollowup().
    function validFollowup() {
      let d = request.resource.data;
      return hasBranchId()
          && d.method in ['whatsapp', 'call', 'visit', 'sms', 'note']
          && d.outcome in ['sent', 'paid', 'promised', 'partial',
                           'no_answer', 'refused', 'dispute', 'note']
          && (d.get('amount', null) == null || (d.amount is number && d.amount >= 0))
          && (d.get('promiseDate', null) == null || d.promiseDate is number)
          && (d.get('nextFollowUp', null) == null || d.nextFollowUp is number)
          && (!('note' in d) || d.note == null || (d.note is string && d.note.size() <= 500));
    }

    match /due_followups/{docId} {
      allow read: if canRead();
      allow create: if isMyBranch(request.resource.data.branchId) && validFollowup();
      allow update: if isMyBranch(resource.data.branchId)
                     && branchIdUnchanged() && validFollowup();
      allow delete: if isMyBranch(resource.data.branchId) && !isCashier();
    }

    match /{collection}/{docId} {
      allow read: if isSyncedCollection(collection) && canRead()
                   && (!isCashier() || cashierReadable(collection));
      allow create: if isSignedIn() && isSyncedCollection(collection)
                     && hasBranchId() && isMyBranch(request.resource.data.branchId)
                     && (!isCashier() || cashierMayCreate(collection));
      allow update: if isSignedIn() && isSyncedCollection(collection)
                     && hasBranchId() && branchIdUnchanged()
                     && isMyBranch(resource.data.branchId)
                     && (!isCashier() || cashierMayUpdate(collection));
      allow delete: if isSignedIn() && isSyncedCollection(collection)
                     && isMyBranch(resource.data.branchId) && !isCashier();
    }

    // Crash reports: app ki ghalti (stack trace) developer ko — sirf banana, branch member device, chhota text,
    // apna uid. Padhna / badalna / mitana app se nahi (sirf Firebase console). lib/services/crash_reporter.dart.
    match /crash_reports/{docId} {
      allow create: if isSignedIn()
                    && exists(/databases/$(database)/documents/branch_members/$(request.auth.uid))
                    && request.resource.data.keys().hasOnly(['text', 'at', 'device', 'branchId', 'app', 'uid'])
                    && request.resource.data.text is string
                    && request.resource.data.text.size() <= 8000
                    && request.resource.data.uid == request.auth.uid;
      allow read, update, delete: if false;
    }

    // Deny everything else by default.
    match /{document=**} {
      allow read, write: if false;
    }
  }
}
AHRULES_EOF
  echo "DEVICE ROLES rules -> $PROJECT"
fi
firebase deploy --only firestore:rules --project "$PROJECT"
echo
echo "Ho gaya. Ab dono phone par Sync Now — admin device par sab pehle jaisa hona chahiye."
