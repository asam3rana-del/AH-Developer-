#!/data/data/com.termux/files/usr/bin/env bash
# Hanna POS: privacy policy website Firebase Hosting par (self-contained).
# Chalayein:  bash /sdcard/Download/deploy_privacy_site.sh
# Natija:     https://my-grocery-pos-8a444.web.app/privacy.html
set -e
PROJECT="${1:-my-grocery-pos-8a444}"
command -v firebase >/dev/null 2>&1 || { echo "firebase CLI nahi mila"; exit 1; }
WORK="$HOME/ah_privacy_site"
rm -rf "$WORK" && mkdir -p "$WORK/public" && cd "$WORK"
printf '{\n  "hosting": { "public": "public", "cleanUrls": false }\n}\n' > firebase.json
cat > public/index.html <<'AHPOS_EOF'
<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Hanna POS — Hanna Solutions</title>
<style>body{margin:0;font:16px/1.6 system-ui,sans-serif;color:#16233a;background:#f6f8fb}main{max-width:640px;margin:0 auto;padding:40px 20px}a{color:#1f5fbf}</style>
</head><body><main>
<h1>Hanna POS</h1>
<p>Shop point-of-sale and bookkeeping app by <b>Asam Hameed</b> (Hanna Solutions), Bhikhi, District Sheikhupura, Pakistan.</p>
<ul>
<li><a href="privacy.html">Privacy Policy / پرائیویسی پالیسی</a></li>
<li><a href="privacy.html#english">Delete my data</a> — see section 5</li>
</ul>
<p>Support: <a href="mailto:asam9rana@gmail.com">asam9rana@gmail.com</a> · WhatsApp <a href="https://wa.me/923006296815">0300-6296815</a></p>
</main></body></html>
AHPOS_EOF
cat > public/privacy.html <<'AHPOS_EOF'
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Hanna POS — Privacy Policy | Hanna Solutions</title>
<style>
  :root { --ink:#16233a; --muted:#5b6678; --line:#e3e7ee; --accent:#1f5fbf; }
  * { box-sizing: border-box; }
  body { margin:0; font: 16px/1.6 system-ui, -apple-system, "Segoe UI", Roboto, sans-serif; color:var(--ink); background:#f6f8fb; }
  main { max-width: 780px; margin: 0 auto; padding: 28px 20px 60px; background:#fff; min-height:100vh; }
  h1 { font-size: 1.7rem; margin: 0 0 4px; }
  h2 { font-size: 1.15rem; margin: 28px 0 8px; border-top:1px solid var(--line); padding-top:20px; }
  .meta { color: var(--muted); font-size: .92rem; margin-bottom: 18px; }
  ul { padding-left: 1.2em; } li { margin: 4px 0; }
  a { color: var(--accent); }
  .lang { display:flex; gap:10px; margin: 0 0 18px; }
  .lang a { padding:4px 12px; border:1px solid var(--line); border-radius:999px; text-decoration:none; }
  .ur { direction: rtl; text-align: right; font-family: "Noto Nastaliq Urdu", "Jameel Noori Nastaleeq", serif; line-height: 2.1; }
  .ur ul { padding-right: 1.2em; padding-left: 0; }
  .box { background:#f1f5fd; border:1px solid #d6e2f7; border-radius:10px; padding:12px 16px; }
</style>
</head>
<body>
<main>
<h1>Hanna POS — Privacy Policy</h1>
<div class="meta">Developer: <b>Asam Hameed</b> (Hanna Solutions), Bhikhi, District Sheikhupura, Pakistan · Last updated: 11 November 2026</div>
<div class="lang"><a href="#english">English</a><a href="#urdu">اردو</a></div>

<section id="english">
<p>Hanna POS ("the app") is a point-of-sale and bookkeeping app for shops. It is used by the shop owner and the staff
the owner adds. This policy explains what information the app handles, where it is kept and how to have it deleted.</p>

<h2>1. Information the app handles</h2>
<ul>
  <li><b>Business records entered by the shop:</b> sales, purchases, payments, expenses, cash register, stock and items,
      customer and supplier ledgers, worker, rent and utility records.</li>
  <li><b>People in those records:</b> names, phone numbers, notes and optional photos of customers, suppliers and workers,
      entered by the shop.</li>
  <li><b>Staff accounts:</b> username, display name and role. Passwords are stored only as a one-way hash, never as plain text.</li>
  <li><b>Phone number for OTP login</b> (only if the shop turns OTP login on), verified through Google Firebase Authentication.</li>
  <li><b>A random device ID</b> created by Firebase, used to let a registered device sync with its own shop's data.</li>
</ul>
<p>The app does <b>not</b> show ads, does not use advertising or analytics trackers, and does not sell or rent any data.</p>

<h2>2. Where the information is kept</h2>
<ul>
  <li><b>On the device</b> in the app's private database. This is always the main copy.</li>
  <li><b>Cloud sync (optional):</b> when the shop turns on Cloud Sync, records are copied to Google Cloud Firestore
      (Firebase) so the shop's devices stay in step. Each shop's data is kept under its own branch and access rules
      allow only that shop's registered devices to read it. Data is sent over encrypted (HTTPS) connections.</li>
  <li><b>Backups:</b> backup files are encrypted with a password chosen by the shop (AES-256) and saved where the shop chooses.</li>
</ul>

<h2>3. Device permissions</h2>
<ul>
  <li><b>Camera / photos:</b> to scan supplier bills (text is read on the device; the picture is not uploaded) and to attach a party photo.</li>
  <li><b>Contacts:</b> only when you choose to pick a phone number from your contacts; only the chosen name and number are saved.</li>
  <li><b>Bluetooth, USB, local network (and on older Android, location for Bluetooth scanning):</b> only to find and use a receipt printer. Location is not stored or sent.</li>
  <li><b>Notifications:</b> due-payment and collection reminders.</li>
  <li><b>Fingerprint / face unlock:</b> handled by your phone; the app never receives biometric data.</li>
  <li><b>Background sync:</b> keeps the shop's data in sync while the app is minimised.</li>
</ul>

<h2>4. Sharing</h2>
<p>Information is shared only with the service providers needed to run the app — Google Firebase (database, login,
and hosting) — and only to provide those services. When the shop sends a bill or reminder by WhatsApp or SMS, that
message goes through the app the shop chooses. We may disclose information if required by Pakistani law.</p>

<h2>5. Keeping and deleting data</h2>
<ul>
  <li>Data stays until the shop deletes it. Records can be deleted inside the app (deleted items go to the Recycle Bin first).</li>
  <li>Uninstalling the app removes the on-device copy. Cloud copies remain until deleted.</li>
  <li><b>To delete a shop's cloud data or a staff account</b>, email <a href="mailto:asam9rana@gmail.com">asam9rana@gmail.com</a>
      or WhatsApp <a href="https://wa.me/923006296815">0300-6296815</a> from the shop owner's number with the shop / branch name.
      We will delete it within 30 days and confirm.</li>
</ul>

<h2>6. Security</h2>
<p>We use hashed passwords, encrypted backups, encrypted connections and per-shop access rules. No method is 100% secure,
so please keep your phone locked and your passwords and backup password private.</p>

<h2>7. Children</h2>
<p>The app is a business tool for adults and is not intended for children under 13.</p>

<h2>8. Changes</h2>
<p>If this policy changes, the new version will be posted on this page with a new date.</p>

<h2>9. Contact</h2>
<div class="box">Asam Hameed — Hanna Solutions · Bhikhi, District Sheikhupura, Punjab, Pakistan<br>
Email: <a href="mailto:asam9rana@gmail.com">asam9rana@gmail.com</a> · Phone / WhatsApp: <a href="tel:+923006296815">0300-6296815</a></div>
</section>

<section id="urdu" class="ur">
<h2>اردو خلاصہ</h2>
<p>Hanna POS دکان کا حساب کتاب رکھنے والی ایپ ہے (Asam Hameed — Hanna Solutions، بھکھی، ضلع شیخوپورہ)۔</p>
<ul>
  <li>ایپ میں وہی معلومات ہوتی ہیں جو دکان خود درج کرے: بِل، خریداری، ادائیگیاں، خرچے، اسٹاک، گاہک / سپلائر کے نام اور فون نمبر۔</li>
  <li>اصل ڈیٹا آپ کے فون میں رہتا ہے۔ کلاؤڈ سنک آن ہو تو Google Firebase پر صرف آپ کی دکان کی برانچ میں محفوظ ہوتا ہے۔</li>
  <li>پاس ورڈ سیدھا محفوظ نہیں ہوتا (ہیش)، بیک اپ پاس ورڈ سے انکرپٹڈ ہوتا ہے۔</li>
  <li>کیمرہ صرف بِل اسکین / تصویر کے لیے، کانٹیکٹس صرف نمبر چننے کے لیے، بلوٹوتھ صرف پرنٹر کے لیے۔</li>
  <li>کوئی اشتہار نہیں، کوئی ٹریکنگ نہیں، ڈیٹا کسی کو بیچا نہیں جاتا۔</li>
  <li>کلاؤڈ ڈیٹا یا اسٹاف اکاؤنٹ ختم کروانے کے لیے: <a href="mailto:asam9rana@gmail.com">asam9rana@gmail.com</a>
      یا واٹس ایپ <a href="https://wa.me/923006296815">0300-6296815</a> — 30 دن کے اندر ختم کر دیا جائے گا۔</li>
</ul>
</section>
</main>
</body>
</html>
AHPOS_EOF
echo "Deploying privacy site to: $PROJECT"
firebase deploy --only hosting --project "$PROJECT"
echo
echo "Ho gaya. Kholein: https://$PROJECT.web.app/privacy.html"
